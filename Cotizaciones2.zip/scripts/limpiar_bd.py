import os
import sys

def limpiar_bd_local(conservar_catalogos=True):
    import sqlite3
    db_path = os.path.join(os.path.dirname(__file__), "..", "data", "cenam_contingencia.db")
    if not os.path.exists(db_path):
        print(f"[LOCAL] El archivo de base de datos {db_path} no existe.")
        return
    
    conn = sqlite3.connect(db_path)
    c = conn.cursor()
    
    # Tablas transaccionales
    c.execute("DELETE FROM partidas")
    c.execute("DELETE FROM sub_solicitudes_at")
    c.execute("DELETE FROM solicitudes_master")
    c.execute("DELETE FROM consultas_especialistas")
    
    if not conservar_catalogos:
        c.execute("DELETE FROM catalogo_servicios")
        c.execute("DELETE FROM areas_tecnicas")
        print("[LOCAL] Catálogos y áreas técnicas eliminados.")
    else:
        print("[LOCAL] Catálogos de servicios y áreas técnicas CONSERVADOS.")
        
    conn.commit()
    conn.close()
    print("[LOCAL] Solicitudes, sub-solicitudes y partidas eliminadas exitosamente (Folios listos para iniciar en limpio).")

def limpiar_bd_cloud(conservar_catalogos=True):
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "nube_segura")))
    import cloud_db as cdb
    
    conn, engine = cdb.get_db_connection()
    c = conn.cursor()
    
    # Tablas transaccionales
    c.execute("DELETE FROM partidas")
    c.execute("DELETE FROM sub_solicitudes_at")
    c.execute("DELETE FROM solicitudes_master")
    c.execute("DELETE FROM consultas_especialistas")
    c.execute("DELETE FROM bitacora_auditoria")
    
    if not conservar_catalogos:
        c.execute("DELETE FROM catalogo_servicios")
        c.execute("DELETE FROM areas_tecnicas")
        c.execute("DELETE FROM usuarios")
        print("[NUBE] Catálogos, áreas y usuarios eliminados.")
    else:
        print("[NUBE] Usuarios, catálogos y áreas técnicas CONSERVADOS.")
        
    conn.commit()
    conn.close()
    print("[NUBE] Base de datos Supabase limpiada exitosamente.")

def limpiar_documentos_generados():
    gen_dir = os.path.join(os.path.dirname(__file__), "..", "generated_docs")
    if os.path.exists(gen_dir):
        count = 0
        for root, dirs, files in os.walk(gen_dir):
            for f in files:
                if f.endswith('.pdf'):
                    try:
                        os.remove(os.path.join(root, f))
                        count += 1
                    except Exception:
                        pass
        print(f"[DOCUMENTOS] Se eliminaron {count} archivos PDF de prueba en 'generated_docs/'.")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Herramienta de limpieza de base de datos CENAM")
    parser.add_argument("--modo", choices=["local", "cloud", "ambas"], default="ambas", help="Base de datos a limpiar")
    parser.add_argument("--todo", action="store_true", help="Eliminar también catálogos y usuarios (por defecto se conservan)")
    parser.add_argument("--limpiar-pdfs", action="store_true", help="Eliminar también los PDFs generados")
    args = parser.parse_args()
    
    print("="*60)
    print("INICIANDO LIMPIEZA DE BASE DE DATOS")
    print("="*60)
    
    if args.modo in ["local", "ambas"]:
        limpiar_bd_local(conservar_catalogos=not args.todo)
    if args.modo in ["cloud", "ambas"]:
        limpiar_bd_cloud(conservar_catalogos=not args.todo)
    if args.limpiar_pdfs:
        limpiar_documentos_generados()
        
    print("="*60)
    print("LIMPIEZA FINALIZADA CON ÉXITO")
    print("="*60)
