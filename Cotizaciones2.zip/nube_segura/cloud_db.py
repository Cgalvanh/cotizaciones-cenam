import os
import sqlite3
import csv
import hashlib
import urllib.parse
import re
from datetime import datetime, timedelta

# Cargar variables de entorno desde .env
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))
    load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))
except Exception:
    pass

def get_database_url():
    """Obtiene la URL de base de datos desde entorno o archivos .env."""
    url = os.getenv("DATABASE_URL", "").strip()
    if not url:
        for p in [os.path.join(os.path.dirname(__file__), ".env"), os.path.join(os.path.dirname(__file__), "..", ".env")]:
            if os.path.exists(p):
                try:
                    with open(p, "r", encoding="utf-8") as f:
                        for line in f:
                            l = line.strip()
                            if l.startswith("DATABASE_URL=") and not l.startswith("#"):
                                val = l.split("=", 1)[1].strip().strip('"').strip("'")
                                if val:
                                    url = val
                                    os.environ["DATABASE_URL"] = url
                                    break
                except Exception:
                    pass
            if url:
                break
    return url

def parse_db_url(url):
    """
    Parsea una URL de base de datos sin depender de urllib.parse.urlsplit
    para evitar fallos por corchetes en contraseñas o placeholders como [YOUR-PASSWORD]
    en Python 3.12+/3.14 (RFC 3986 / CVE IPv6 address check).
    """
    if not url:
        return None
    url = str(url).strip()
    pattern = r'^(?P<scheme>[a-zA-Z0-9\+]+)://(?:(?P<user>[^:@]+)(?::(?P<password>.*))?@)?(?P<host>[a-zA-Z0-9\.-]+)(?::(?P<port>\d+))?(?:/(?P<dbname>[^?]*))?(?:\?(?P<query>.*))?$'
    m = re.match(pattern, url)
    if not m:
        return None
    d = m.groupdict()
    d['port'] = int(d['port']) if d['port'] else 5432
    d['dbname'] = d['dbname'] or 'postgres'
    d['query'] = d['query'] or 'sslmode=require'
    d['user'] = d['user'] or 'postgres'
    d['password'] = d['password'] or ''
    return d

def update_supabase_password(new_password):
    """Actualiza la contraseña de Supabase en los archivos .env."""
    new_password = str(new_password).strip()
    # Si el usuario introdujo corchetes alrededor de su contraseña, limpiarlos
    if new_password.startswith("[") and new_password.endswith("]"):
        new_password = new_password[1:-1].strip()
        
    for env_path in [
        os.path.abspath(os.path.join(os.path.dirname(__file__), ".env")),
        os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".env"))
    ]:
        lines = []
        replaced = False
        if os.path.exists(env_path):
            with open(env_path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip().startswith("DATABASE_URL="):
                        val = line.strip().split("=", 1)[1].strip().strip('"').strip("'")
                        p = parse_db_url(val)
                        if p and p.get("host"):
                            user = p["user"] or "postgres"
                            host = p["host"]
                            port = f":{p['port']}" if p.get("port") else ":5432"
                            dbname = f"/{p['dbname']}" if p.get("dbname") else "/postgres"
                            query = f"?{p['query']}" if p.get("query") else "?sslmode=require"
                            new_url = f"postgresql://{user}:{new_password}@{host}{port}{dbname}{query}"
                            lines.append(f"DATABASE_URL={new_url}\n")
                            os.environ["DATABASE_URL"] = new_url
                            replaced = True
                        else:
                            new_url = f"postgresql://postgres.lmvpzqniqjhdtjmmxvdg:{new_password}@aws-0-us-east-1.pooler.supabase.com:5432/postgres?sslmode=prefer"
                            lines.append(f"DATABASE_URL={new_url}\n")
                            os.environ["DATABASE_URL"] = new_url
                            replaced = True
                    else:
                        lines.append(line)
        if not replaced:
            new_url = f"postgresql://postgres.lmvpzqniqjhdtjmmxvdg:{new_password}@aws-0-us-east-1.pooler.supabase.com:5432/postgres?sslmode=prefer"
            lines.append(f"DATABASE_URL={new_url}\n")
            os.environ["DATABASE_URL"] = new_url
            
        with open(env_path, "w", encoding="utf-8") as f:
            f.writelines(lines)

def test_postgres_connection(db_url):
    """Prueba la conexión a PostgreSQL tanto en modo directo como con el pooler IPv4 de Supabase."""
    if not db_url or "YOUR-PASSWORD" in db_url:
        return False, "La contraseña no ha sido configurada (aún contiene el marcador YOUR-PASSWORD).", None
    try:
        import psycopg2
    except ImportError:
        return False, "La biblioteca psycopg2 no está instalada.", None
        
    p = parse_db_url(db_url)
    if not p:
        return False, "La URL de conexión no tiene un formato válido.", None

    # Si la URL apunta directamente al pooler IPv4 de Supabase
    if p['host'] and "pooler.supabase.com" in p['host']:
        try:
            conn = psycopg2.connect(
                host=p['host'],
                port=p['port'],
                user=p['user'],
                password=p['password'],
                dbname=p['dbname'],
                sslmode="prefer",
                connect_timeout=6
            )
            conn.close()
            return True, "Conexión exitosa vía Connection Pooler IPv4 de Supabase.", "POOLER"
        except Exception as pool_err:
            return False, f"Fallo al conectar al Pooler IPv4: {pool_err}", None

    # 1. Intento Directo (timeout corto 2s para no bloquear si la red local no enruta IPv6)
    try:
        conn = psycopg2.connect(
            host=p['host'],
            port=p['port'],
            user=p['user'],
            password=p['password'],
            dbname=p['dbname'],
            sslmode="prefer",
            connect_timeout=2
        )
        conn.close()
        return True, "Conexión directa PostgreSQL exitosa.", "DIRECT"
    except Exception as direct_err:
        # 2. Intento Pooler IPv4 de Supabase (us-east-1)
        try:
            if p['host'] and "supabase.co" in p['host'] and p['host'].startswith("db."):
                project_ref = p['host'].split(".")[1]
                pooler_host = "aws-0-us-east-1.pooler.supabase.com"
                base_user = p['user']
                pooler_user = f"{base_user}.{project_ref}" if not base_user.endswith(f".{project_ref}") else base_user
                conn = psycopg2.connect(
                    host=pooler_host,
                    port=5432,
                    user=pooler_user,
                    password=p['password'],
                    dbname=p['dbname'],
                    sslmode="prefer",
                    connect_timeout=6
                )
                conn.close()
                return True, "Conexión exitosa vía Connection Pooler IPv4 de Supabase.", "POOLER"
        except Exception as pooler_err:
            return False, f"Fallo directo: {direct_err} | Fallo Pooler IPv4: {pooler_err}", None
        return False, f"Fallo al conectar: {direct_err}", None

class UnifiedCursor:
    def __init__(self, cursor, engine):
        self.cursor = cursor
        self.engine = engine
        self.lastrowid = None
        
    def execute(self, sql, params=()):
        if self.engine == "POSTGRES":
            sql_conv = sql.replace("?", "%s")
            is_insert = sql_conv.strip().upper().startswith("INSERT INTO")
            if is_insert and "RETURNING" not in sql_conv.upper():
                sql_conv += " RETURNING id"
                self.cursor.execute(sql_conv, params)
                res = self.cursor.fetchone()
                self.lastrowid = res[0] if res else None
                return self
            self.cursor.execute(sql_conv, params)
            return self
        else:
            self.cursor.execute(sql, params)
            self.lastrowid = self.cursor.lastrowid
            return self

    def fetchone(self):
        return self.cursor.fetchone()
        
    def fetchall(self):
        return self.cursor.fetchall()

# Pool y Caches en Memoria para Alto Rendimiento
_PG_POOL = None
_AREAS_CACHE = None
_SERVICIOS_CACHE = {}

def get_pg_pool():
    global _PG_POOL
    if _PG_POOL is not None:
        try:
            if not _PG_POOL.closed:
                return _PG_POOL
        except Exception:
            _PG_POOL = None
            
    db_url = get_database_url()
    if not (db_url.startswith("postgresql://") or db_url.startswith("postgres://")) or "YOUR-PASSWORD" in db_url:
        return None
        
    p = parse_db_url(db_url)
    if not p or not p.get("host") or not p.get("password"):
        return None

    try:
        import psycopg2.pool
        # Si la URL apunta directamente al pooler IPv4 de Supabase
        if p['host'] and "pooler.supabase.com" in p['host']:
            pool = psycopg2.pool.ThreadedConnectionPool(
                minconn=2, maxconn=15,
                host=p['host'],
                port=p['port'],
                user=p['user'],
                password=p['password'],
                dbname=p['dbname'],
                sslmode="prefer",
                connect_timeout=6
            )
            pool.connection_type = "POOLER"
            _PG_POOL = pool
            return _PG_POOL

        # 1. Intentar conexión directa (timeout corto 2s para evitar demoras si no hay IPv6)
        try:
            pool = psycopg2.pool.ThreadedConnectionPool(
                minconn=2, maxconn=15,
                host=p['host'],
                port=p['port'],
                user=p['user'],
                password=p['password'],
                dbname=p['dbname'],
                sslmode="prefer",
                connect_timeout=2
            )
            pool.connection_type = "DIRECT"
            _PG_POOL = pool
            return _PG_POOL
        except Exception:
            # 2. Intentar Pooler IPv4 de Supabase (us-east-1)
            if p['host'] and "supabase.co" in p['host'] and p['host'].startswith("db."):
                project_ref = p['host'].split(".")[1]
                pooler_host = "aws-0-us-east-1.pooler.supabase.com"
                base_user = p['user']
                pooler_user = f"{base_user}.{project_ref}" if not base_user.endswith(f".{project_ref}") else base_user
                pool = psycopg2.pool.ThreadedConnectionPool(
                    minconn=2, maxconn=15,
                    host=pooler_host,
                    port=5432,
                    user=pooler_user,
                    password=p['password'],
                    dbname=p['dbname'],
                    sslmode="prefer",
                    connect_timeout=6
                )
                pool.connection_type = "POOLER"
                _PG_POOL = pool
                return _PG_POOL
    except Exception as e:
        print(f"Error inicializando connection pool: {e}")
        _PG_POOL = None
    return None

class UnifiedConnection:
    def __init__(self, conn, engine, connection_type="DIRECT"):
        self.conn = conn
        self.engine = engine
        self.connection_type = connection_type

    def cursor(self):
        if self.engine == "POSTGRES":
            import psycopg2.extras
            return UnifiedCursor(self.conn.cursor(cursor_factory=psycopg2.extras.DictCursor), self.engine)
        else:
            return UnifiedCursor(self.conn.cursor(), self.engine)

    def commit(self):
        self.conn.commit()

    def rollback(self):
        self.conn.rollback()

    def close(self):
        self.conn.close()

class PooledUnifiedConnection(UnifiedConnection):
    """Conexión ultra-rápida gestionada por el ThreadedConnectionPool."""
    def __init__(self, raw_conn, pool, engine, connection_type="DIRECT"):
        super().__init__(raw_conn, engine, connection_type)
        self.pool = pool
        self._closed = False

    def close(self):
        if not self._closed:
            self._closed = True
            try:
                self.conn.commit()
            except Exception:
                pass
            try:
                self.pool.putconn(self.conn)
            except Exception:
                pass

def get_db_connection():
    """Obtiene una conexión viva en menos de 1 ms mediante el pool persistente."""
    pool = get_pg_pool()
    if pool is not None:
        try:
            raw_conn = pool.getconn()
            if raw_conn.closed != 0:
                try:
                    pool.putconn(raw_conn, close=True)
                except Exception:
                    pass
                raw_conn = pool.getconn()
            ctype = getattr(pool, "connection_type", "DIRECT")
            return PooledUnifiedConnection(raw_conn, pool, "POSTGRES", ctype), "POSTGRES"
        except Exception as e:
            print(f"Advertencia: Error al obtener conexion del pool ({e}). Usando SQLite local.")

    db_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "cloud_cenam_secure.db"))
    raw_conn = sqlite3.connect(db_path)
    raw_conn.row_factory = sqlite3.Row
    return UnifiedConnection(raw_conn, "SQLITE", "LOCAL_SQLITE"), "SQLITE"

def hash_password(password: str) -> str:
    salt = "cenam_secure_salt_2026"
    return hashlib.sha256((password + salt).encode("utf-8")).hexdigest()

def verify_credentials(correo, password):
    conn, engine = get_db_connection()
    c = conn.cursor()
    pwd_hash = hash_password(password)
    c.execute("SELECT id, correo, nombre_completo, rol, clave_area, activo FROM usuarios WHERE correo = ? AND password_hash = ?", (correo, pwd_hash))
    user = c.fetchone()
    conn.close()
    if user and user['activo']:
        return dict(user)
    return None

def init_cloud_db():
    conn, engine = get_db_connection()
    c = conn.cursor()
    
    if engine == "POSTGRES":
        c.execute("SELECT to_regclass('public.usuarios');")
        res = c.fetchone()
        table_exists = res and res[0] is not None
        if not table_exists:
            schema_path = os.path.join(os.path.dirname(__file__), "supabase_schema.sql")
            if os.path.exists(schema_path):
                with open(schema_path, "r", encoding="utf-8") as f:
                    schema_sql = f.read()
                raw_cursor = conn.conn.cursor()
                raw_cursor.execute(schema_sql)
                conn.commit()
                print("Esquema de Supabase PostgreSQL auto-inicializado con éxito.")
        else:
            # Comprobación de alta velocidad: si el esquema ya está migrado, salir en menos de 0.1s
            try:
                raw_c = conn.conn.cursor()
                raw_c.execute("SELECT 1 FROM information_schema.columns WHERE table_schema = %s AND table_name = %s AND column_name = %s", ("public", "solicitudes_master", "representante_legal_cenam"))
                if raw_c.fetchone():
                    conn.close()
                    return
            except Exception:
                pass

            # Migraciones en Postgres si aún faltan columnas
            def add_pg_col(table, col, col_type):
                try:
                    raw_c = conn.conn.cursor()
                    raw_c.execute(f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {col} {col_type};")
                    conn.commit()
                except Exception:
                    conn.rollback()

            def convert_to_int(table, col, default_val=0):
                try:
                    raw_c = conn.conn.cursor()
                    raw_c.execute(f"ALTER TABLE {table} ALTER COLUMN {col} DROP DEFAULT;")
                    raw_c.execute(f"ALTER TABLE {table} ALTER COLUMN {col} TYPE INTEGER USING (CASE WHEN {col}::text IN ('true', 't', '1') THEN 1 ELSE 0 END);")
                    raw_c.execute(f"ALTER TABLE {table} ALTER COLUMN {col} SET DEFAULT {default_val};")
                    conn.commit()
                except Exception:
                    conn.rollback()

            convert_to_int("solicitudes_master", "es_extranjero", 0)
            convert_to_int("solicitudes_master", "aplica_iva", 1)
            convert_to_int("solicitudes_master", "es_in_situ", 0)
            convert_to_int("partidas", "es_manual", 0)
            convert_to_int("partidas", "es_no_realizable", 0)
            convert_to_int("usuarios", "activo", 1)

            try:
                raw_c = conn.conn.cursor()
                raw_c.execute("ALTER TABLE solicitudes_master DROP CONSTRAINT IF EXISTS solicitudes_master_estado_check;")
                raw_c.execute("ALTER TABLE sub_solicitudes_at DROP CONSTRAINT IF EXISTS sub_solicitudes_at_estado_check;")
                conn.commit()
            except Exception:
                conn.rollback()

            add_pg_col("solicitudes_master", "representante_legal_cenam", "TEXT")
            add_pg_col("solicitudes_master", "vigencia_programacion", "TEXT DEFAULT '3 semanas'")
            add_pg_col("solicitudes_master", "modalidad_retorno", "TEXT")
            add_pg_col("solicitudes_master", "direccion_servicio_sitio", "TEXT")
            add_pg_col("solicitudes_master", "condiciones_acceso_planta", "TEXT")
            add_pg_col("solicitudes_master", "fecha_aceptacion_cotizacion", "TEXT")
            add_pg_col("solicitudes_master", "fecha_confirmacion_programa", "TEXT")

            add_pg_col("sub_solicitudes_at", "fecha_recepcion_prog", "TEXT")
            add_pg_col("sub_solicitudes_at", "fecha_inicio_prog", "TEXT")
            add_pg_col("sub_solicitudes_at", "fecha_entrega_prog", "TEXT")
            add_pg_col("sub_solicitudes_at", "fecha_limite_prog", "TEXT")
            add_pg_col("sub_solicitudes_at", "motivo_reprogramacion", "TEXT")

            add_pg_col("partidas", "certificado_anterior", "TEXT")
            add_pg_col("partidas", "magnitud", "TEXT")
            add_pg_col("partidas", "exactitud_clase", "TEXT")
            add_pg_col("partidas", "condiciones_particulares", "TEXT")
            add_pg_col("partidas", "aceptada_cliente", "INTEGER DEFAULT 1")
            add_pg_col("partidas", "fecha_recepcion_equipo", "TEXT")
            add_pg_col("partidas", "fecha_inicio_calibracion", "TEXT")
            add_pg_col("partidas", "fecha_fin_calibracion", "TEXT")
            add_pg_col("partidas", "fecha_entrega_equipo", "TEXT")
            add_pg_col("partidas", "fecha_entrega_resultados", "TEXT")
            add_pg_col("partidas", "fecha_limite_aceptacion", "TEXT")
    else:
        c.execute("PRAGMA foreign_keys = ON;")
        
        c.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id TEXT PRIMARY KEY,
            correo TEXT UNIQUE NOT NULL,
            nombre_completo TEXT NOT NULL,
            rol TEXT NOT NULL,
            clave_area TEXT,
            password_hash TEXT NOT NULL,
            activo INTEGER DEFAULT 1
        );
        """)
        
        c.execute("""
        CREATE TABLE IF NOT EXISTS areas_tecnicas (
            clave TEXT PRIMARY KEY,
            nombre TEXT NOT NULL
        );
        """)
        
        c.execute("""
        CREATE TABLE IF NOT EXISTS catalogo_servicios (
            clave_servicio TEXT PRIMARY KEY,
            clave_area TEXT NOT NULL,
            nombre_tramite TEXT,
            supuesto TEXT NOT NULL,
            alcance TEXT,
            observaciones TEXT,
            costo REAL NOT NULL,
            fundamento_juridico TEXT,
            es_in_situ TEXT DEFAULT 'NO',
            dias_habiles_defecto INTEGER DEFAULT 5
        );
        """)
        
        c.execute("""
        CREATE TABLE IF NOT EXISTS solicitudes_master (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            no_solicitud TEXT UNIQUE NOT NULL,
            no_folio TEXT UNIQUE NOT NULL,
            no_cotizacion TEXT,
            version INTEGER DEFAULT 1,
            cliente TEXT NOT NULL,
            representante TEXT,
            telefono TEXT,
            correo TEXT,
            rfc TEXT,
            pais TEXT DEFAULT 'México',
            es_extranjero INTEGER DEFAULT 0,
            aplica_iva INTEGER DEFAULT 1,
            fecha_recepcion TEXT NOT NULL,
            fecha_emision TEXT,
            vigencia TEXT,
            estado TEXT DEFAULT 'TURNADA',
            es_in_situ INTEGER DEFAULT 0,
            representante_legal_cenam TEXT,
            vigencia_programacion TEXT DEFAULT '3 semanas',
            modalidad_retorno TEXT,
            direccion_servicio_sitio TEXT,
            condiciones_acceso_planta TEXT,
            fecha_aceptacion_cotizacion TEXT,
            fecha_confirmacion_programa TEXT
        );
        """)
        
        c.execute("""
        CREATE TABLE IF NOT EXISTS sub_solicitudes_at (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            solicitud_id INTEGER NOT NULL,
            clave_area TEXT NOT NULL,
            estado TEXT DEFAULT 'ASIGNADA',
            motivo_devolucion TEXT,
            area_sugerida TEXT,
            fecha_asignacion TEXT NOT NULL,
            fecha_limite_sla TEXT NOT NULL,
            fecha_recepcion_prog TEXT,
            fecha_inicio_prog TEXT,
            fecha_entrega_prog TEXT,
            fecha_limite_prog TEXT,
            motivo_reprogramacion TEXT
        );
        """)
        
        c.execute("""
        CREATE TABLE IF NOT EXISTS partidas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sub_solicitud_id INTEGER,
            solicitud_id INTEGER NOT NULL,
            numero_partida INTEGER NOT NULL,
            descripcion_equipo TEXT NOT NULL,
            marca TEXT,
            modelo TEXT,
            no_serie TEXT,
            id_interno TEXT,
            alcance_solicitado TEXT,
            certificado_anterior TEXT,
            magnitud TEXT,
            exactitud_clase TEXT,
            condiciones_particulares TEXT,
            es_manual INTEGER DEFAULT 0,
            clave_servicio TEXT,
            descripcion_servicio TEXT,
            tiempo_dias_habiles INTEGER DEFAULT 5,
            cantidad INTEGER DEFAULT 1,
            precio_unitario REAL DEFAULT 0.0,
            precio_total REAL DEFAULT 0.0,
            es_no_realizable INTEGER DEFAULT 0,
            motivo_dsnr TEXT,
            aceptada_cliente INTEGER DEFAULT 1,
            fecha_recepcion_equipo TEXT,
            fecha_inicio_calibracion TEXT,
            fecha_fin_calibracion TEXT,
            fecha_entrega_equipo TEXT,
            fecha_entrega_resultados TEXT,
            fecha_limite_aceptacion TEXT
        );
        """)
        
        c.execute("""
        CREATE TABLE IF NOT EXISTS consultas_especialistas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sub_solicitud_id INTEGER NOT NULL,
            especialista_nombre TEXT NOT NULL,
            pregunta TEXT NOT NULL,
            respuesta TEXT,
            fecha_consulta TEXT NOT NULL,
            fecha_respuesta TEXT,
            estado TEXT DEFAULT 'PENDIENTE'
        );
        """)
        
        c.execute("""
        CREATE TABLE IF NOT EXISTS bitacora_auditoria (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_correo TEXT NOT NULL,
            accion TEXT NOT NULL,
            entidad TEXT NOT NULL,
            registro_id TEXT,
            detalles TEXT,
            fecha TEXT NOT NULL
        );
        """)
        
        conn.commit()

        # Migraciones en SQLite local
        def add_sqlite_col(table, col, col_type):
            c.execute(f"PRAGMA table_info({table});")
            cols = [r[1] for r in c.fetchall()]
            if col not in cols:
                try:
                    c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {col_type};")
                except Exception:
                    pass

        add_sqlite_col("solicitudes_master", "representante_legal_cenam", "TEXT")
        add_sqlite_col("solicitudes_master", "vigencia_programacion", "TEXT DEFAULT '3 semanas'")
        add_sqlite_col("solicitudes_master", "modalidad_retorno", "TEXT")
        add_sqlite_col("solicitudes_master", "direccion_servicio_sitio", "TEXT")
        add_sqlite_col("solicitudes_master", "condiciones_acceso_planta", "TEXT")
        add_sqlite_col("solicitudes_master", "fecha_aceptacion_cotizacion", "TEXT")
        add_sqlite_col("solicitudes_master", "fecha_confirmacion_programa", "TEXT")

        add_sqlite_col("sub_solicitudes_at", "fecha_recepcion_prog", "TEXT")
        add_sqlite_col("sub_solicitudes_at", "fecha_inicio_prog", "TEXT")
        add_sqlite_col("sub_solicitudes_at", "fecha_entrega_prog", "TEXT")
        add_sqlite_col("sub_solicitudes_at", "fecha_limite_prog", "TEXT")
        add_sqlite_col("sub_solicitudes_at", "motivo_reprogramacion", "TEXT")

        add_sqlite_col("partidas", "certificado_anterior", "TEXT")
        add_sqlite_col("partidas", "magnitud", "TEXT")
        add_sqlite_col("partidas", "exactitud_clase", "TEXT")
        add_sqlite_col("partidas", "condiciones_particulares", "TEXT")
        add_sqlite_col("partidas", "aceptada_cliente", "INTEGER DEFAULT 1")
        add_sqlite_col("partidas", "fecha_recepcion_equipo", "TEXT")
        add_sqlite_col("partidas", "fecha_inicio_calibracion", "TEXT")
        add_sqlite_col("partidas", "fecha_fin_calibracion", "TEXT")
        add_sqlite_col("partidas", "fecha_entrega_equipo", "TEXT")
        add_sqlite_col("partidas", "fecha_entrega_resultados", "TEXT")
        add_sqlite_col("partidas", "fecha_limite_aceptacion", "TEXT")
        conn.commit()
        seed_cloud_initial_data(conn, engine)
        
    conn.close()

def seed_cloud_initial_data(conn, engine):
    c = conn.cursor()
    areas_path = os.path.join(os.path.dirname(__file__), "data", "areas_tecnicas.csv")
    if os.path.exists(areas_path):
        with open(areas_path, mode="r", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                c.execute("INSERT OR REPLACE INTO areas_tecnicas (clave, nombre) VALUES (?, ?)", (row['Clave'].strip(), row['Nombre'].strip()))
                
    c.execute("SELECT COUNT(*) FROM catalogo_servicios")
    cnt = c.fetchone()[0]
    cat_path = os.path.join(os.path.dirname(__file__), "data", "catalogo_servicios.csv")
    if cnt == 0 and os.path.exists(cat_path):
        with open(cat_path, mode="r", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                c.execute("""
                INSERT INTO catalogo_servicios (
                    clave_servicio, clave_area, nombre_tramite, supuesto,
                    alcance, observaciones, costo, fundamento_juridico,
                    es_in_situ, dias_habiles_defecto
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    row['Clave_Servicio'], row['Clave_Area'], row['Nombre_Tramite'],
                    row['Supuesto'], row['Alcance'], row['Observaciones'],
                    float(row['Costo']), row['Fundamento_Juridico'],
                    row['Es_In_Situ'], int(row['Dias_Habiles_Defecto'])
                ))

    c.execute("SELECT COUNT(*) FROM usuarios")
    user_cnt = c.fetchone()[0]
    if user_cnt == 0:
        pwd = hash_password("Cenam2026*")
        usuarios_default = [
            ("usr_ssi", "ssi@cenam.mx", "Ventanilla Central SSI", "SSI", None, pwd),
            ("usr_admin", "admin@cenam.mx", "Administrador de Sistemas", "ADMIN", None, pwd),
            ("usr_dim", "at.dimensional@cenam.mx", "Ing. Roberto Nava (AT Dimensional)", "AT", "AT-01", pwd),
            ("usr_elec", "at.electrica@cenam.mx", "Ing. Laura Méndez (AT Eléctrica)", "AT", "AT-02", pwd),
            ("usr_rf", "at.radiofrecuencia@cenam.mx", "Ing. Carlos Vega (AT Radiofrecuencia)", "AT", "AT-03", pwd),
            ("usr_tiempo", "at.tiempo@cenam.mx", "Dra. Patricia Cruz (AT Tiempo)", "AT", "AT-04", pwd),
            ("usr_temp", "at.temperatura@cenam.mx", "M. en C. Luis Morales (AT Termometría)", "AT", "AT-05", pwd),
            ("usr_optica", "at.optica@cenam.mx", "Ing. Daniel Flores (AT Óptica)", "AT", "AT-06", pwd),
            ("usr_masa", "at.masa@cenam.mx", "Ing. Sandra Rangel (AT Masa)", "AT", "AT-07", pwd),
            ("usr_presion", "at.presion@cenam.mx", "Ing. Jorge Salinas (AT Presión)", "AT", "AT-08", pwd),
            ("usr_flujo", "at.flujo@cenam.mx", "M. en C. Elena Torres (AT Flujo)", "AT", "AT-09", pwd),
            ("usr_vibra", "at.acustica@cenam.mx", "Ing. Fernando Rios (AT Acústica)", "AT", "AT-10", pwd),
            ("usr_dureza", "at.dureza@cenam.mx", "Ing. Marco Soto (AT Dureza)", "AT", "AT-11", pwd),
            ("usr_quim", "at.quimica@cenam.mx", "Dra. Carmen Beltrán (AT Química)", "AT", "AT-12", pwd),
            ("usr_fisi", "at.fisicoquimica@cenam.mx", "Dr. Alejandro Luna (AT Fisicoquímica)", "AT", "AT-13", pwd),
            ("usr_insitu", "at.insitu@cenam.mx", "Ing. Héctor Ortiz (AT Servicios In Situ)", "AT", "AT-14", pwd),
        ]
        for u in usuarios_default:
            c.execute("""
            INSERT INTO usuarios (id, correo, nombre_completo, rol, clave_area, password_hash, activo)
            VALUES (?, ?, ?, ?, ?, ?, 1)
            """, u)
            
    conn.commit()

def log_auditoria(usuario_correo, accion, entidad, registro_id, detalles):
    try:
        conn, engine = get_db_connection()
        c = conn.cursor()
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if engine == "POSTGRES":
            import json
            c.execute("""
            INSERT INTO bitacora_auditoria (usuario_correo, accion, entidad, registro_id, detalles, fecha)
            VALUES (?, ?, ?, ?, ?, ?)
            """, (usuario_correo, accion, entidad, str(registro_id), json.dumps(detalles), now_str))
        else:
            c.execute("""
            INSERT INTO bitacora_auditoria (usuario_correo, accion, entidad, registro_id, detalles, fecha)
            VALUES (?, ?, ?, ?, ?, ?)
            """, (usuario_correo, accion, entidad, str(registro_id), str(detalles), now_str))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Error logging audit trail: {e}")

# Consecutivos y Helpers para Nube Segura con Sufijo PR
def get_next_solicitud_number():
    conn, engine = get_db_connection()
    c = conn.cursor()
    year = datetime.now().year
    c.execute("SELECT no_solicitud FROM solicitudes_master ORDER BY id DESC")
    rows = c.fetchall()
    conn.close()
    
    max_num = 0
    for r in rows:
        val = str(r['no_solicitud'] or '')
        m = re.search(r"(\d+)(?:PR)?$", val, re.IGNORECASE)
        if m:
            try:
                digits = m.group(1)
                seq = int(digits[-3:])
                if seq > max_num:
                    max_num = seq
            except ValueError:
                pass
                
    next_seq = max_num + 1
    return f"{year}{next_seq:03d}PR"

def get_next_folio_number():
    conn, engine = get_db_connection()
    c = conn.cursor()
    year = datetime.now().year
    c.execute("SELECT no_folio FROM solicitudes_master ORDER BY id DESC")
    rows = c.fetchall()
    conn.close()
    
    max_num = 0
    for r in rows:
        val = str(r['no_folio'] or '')
        m = re.search(r"^(\d+)-", val)
        if m:
            try:
                seq = int(m.group(1))
                if seq > max_num:
                    max_num = seq
            except ValueError:
                pass
                
    next_seq = max_num + 1
    return f"{next_seq:04d}-{year}PR"

def get_next_cotizacion_number():
    conn, engine = get_db_connection()
    c = conn.cursor()
    year_prefix = datetime.now().year % 100
    c.execute("SELECT no_cotizacion FROM solicitudes_master WHERE no_cotizacion IS NOT NULL ORDER BY id DESC")
    rows = c.fetchall()
    conn.close()
    
    max_num = 0
    for r in rows:
        val = str(r['no_cotizacion'] or '')
        m = re.search(r"(\d+)(?:PR)?$", val, re.IGNORECASE)
        if m:
            try:
                digits = m.group(1)
                seq = int(digits[-4:])
                if seq > max_num:
                    max_num = seq
            except ValueError:
                pass
                
    next_seq = max_num + 1
    return f"{year_prefix:02d}{next_seq:04d}PR"

# Funciones de Cálculo de Días Hábiles
def restar_dias_habiles(fecha_dt, n_dias=2):
    curr = fecha_dt
    dias_restados = 0
    while dias_restados < n_dias:
        curr -= timedelta(days=1)
        if curr.weekday() < 5:
            dias_restados += 1
    return curr

def sumar_dias_habiles(fecha_dt, n_dias):
    curr = fecha_dt
    dias_sumados = 0
    while dias_sumados < n_dias:
        curr += timedelta(days=1)
        if curr.weekday() < 5:
            dias_sumados += 1
    return curr

def get_areas_tecnicas():
    global _AREAS_CACHE
    if _AREAS_CACHE is not None:
        return _AREAS_CACHE
    conn, engine = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT clave, nombre FROM areas_tecnicas ORDER BY clave")
    rows = c.fetchall()
    conn.close()
    _AREAS_CACHE = [{"clave": r["clave"], "nombre": r["nombre"]} for r in rows]
    return _AREAS_CACHE

def get_servicios_por_area(clave_area):
    global _SERVICIOS_CACHE
    if clave_area in _SERVICIOS_CACHE:
        return _SERVICIOS_CACHE[clave_area]
    conn, engine = get_db_connection()
    c = conn.cursor()
    c.execute("""
        SELECT clave_servicio, supuesto, alcance, observaciones, costo, dias_habiles_defecto, es_in_situ
        FROM catalogo_servicios
        WHERE clave_area = ?
        ORDER BY supuesto
    """, (clave_area,))
    rows = c.fetchall()
    conn.close()
    res = [dict(r) for r in rows]
    _SERVICIOS_CACHE[clave_area] = res
    return res
