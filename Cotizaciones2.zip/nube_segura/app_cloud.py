import streamlit as st
import pandas as pd
import os
from datetime import datetime, timedelta, date
import cloud_db as cdb
import pdf_generator as pdf_gen
import request_parser as parser

st.set_page_config(
    page_title="CENAM - Nube Segura (Cotizaciones y Programación)",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Inicializar Base de Datos Segura una sola vez en memoria (Optimización de Rendimiento)
@st.cache_resource(show_spinner=False)
def ensure_cloud_db_ready():
    cdb.init_cloud_db()
    return True

ensure_cloud_db_ready()

# Cache para estatus de conexión a BD (evita handshake de red en cada interacción)
@st.cache_resource(ttl=300, show_spinner=False)
def get_db_status():
    conn, engine = cdb.get_db_connection()
    ctype = getattr(conn, "connection_type", "SQLITE")
    conn.close()
    return engine, ctype

engine_probe, conn_type_probe = get_db_status()
current_db_url = cdb.get_database_url()

# Helpers
def get_sla_badge(fecha_asig_str):
    try:
        f_asig = datetime.strptime(fecha_asig_str, "%Y-%m-%d %H:%M:%S")
        dias_transcurridos = (datetime.now() - f_asig).days
        if dias_transcurridos <= 1:
            return f"🟢 {dias_transcurridos} día(s) (En tiempo)"
        elif dias_transcurridos <= 3:
            return f"🟡 {dias_transcurridos} día(s) (Próximo a vencer - SLA 3 días)"
        else:
            return f"🔴 {dias_transcurridos} día(s) (VENCIDO - Excede 3 días)"
    except Exception:
        return "SLA 3 días hábiles"

# Banner de Mensajes Flash persistentes entre recargas (rerun)
if "flash_msg" in st.session_state:
    m_type, m_text = st.session_state["flash_msg"]
    if m_type == "success":
        st.success(m_text, icon="✅")
    elif m_type == "warning":
        st.warning(m_text, icon="⚠️")
    elif m_type == "info":
        st.info(m_text, icon="ℹ️")
    del st.session_state["flash_msg"]

# Session State para Autenticación Segura (RBAC)
if "user" not in st.session_state:
    st.session_state["user"] = None

# ==========================================
# PANTALLA 0: INICIO DE SESIÓN SEGURO (ZERO TRUST)
# ==========================================
if st.session_state["user"] is None:
    st.markdown("<h2 style='text-align: center; color: #1A365D;'>🛡️ Centro Nacional de Metrología</h2>", unsafe_allow_html=True)
    st.markdown("<h4 style='text-align: center; color: #4A5568;'>Plataforma en Nube Segura - Cotización, Programación y DSNR PR</h4>", unsafe_allow_html=True)
    st.write("")
    
    col_l1, col_l2, col_l3 = st.columns([1, 1.3, 1])
    with col_l2:
        if engine_probe == "POSTGRES":
            st.success(f"☁️ **Conectado a Base de Datos PostgreSQL Supabase** (`{conn_type_probe}`)", icon="✅")
        else:
            if "[YOUR-PASSWORD]" in current_db_url or not current_db_url:
                with st.expander("⚙️ Conexión Supabase PostgreSQL (Requiere Contraseña)", expanded=True):
                    st.info("URI configurada: `postgresql://postgres.lmvpzqniqjhdtjmmxvdg:[PASSWORD]@aws-0-us-east-1.pooler.supabase.com:5432/postgres` (Connection Pooler IPv4 Oficial)")
                    st.caption("Ingrese la contraseña que asignó a su base de datos Supabase para conectar:")
                    supa_pwd = st.text_input("Contraseña de Supabase:", type="password", key="supa_pwd_box")
                    if st.button("🔌 Probar y Conectar a Supabase", type="primary"):
                        if not supa_pwd:
                            st.warning("Ingrese su contraseña de Supabase.")
                        else:
                            test_url = f"postgresql://postgres.lmvpzqniqjhdtjmmxvdg:{supa_pwd.strip()}@aws-0-us-east-1.pooler.supabase.com:5432/postgres?sslmode=prefer"
                            with st.spinner("Probando conexión a Supabase..."):
                                ok, msg, m_type = cdb.test_postgres_connection(test_url)
                            if ok:
                                cdb.update_supabase_password(supa_pwd.strip())
                                cdb.init_cloud_db()
                                st.session_state["flash_msg"] = ("success", f"🎉 Conexión exitosa a Supabase ({m_type}). Base de datos sincronizada.")
                                st.rerun()
                            else:
                                st.error(f"No se pudo conectar a Supabase: {msg}")
            else:
                st.warning("⚠️ Operando con SQLite local de respaldo (PostgreSQL no disponible).", icon="⚠️")

        with st.container(border=True):
            st.subheader("Acceso Autenticado Institucional")
            st.caption("Conexión cifrada TLS 1.3 con almacenamiento seguro AES-256.")
            
            correo_input = st.text_input("Correo Institucional (@cenam.mx)", placeholder="usuario@cenam.mx")
            pwd_input = st.text_input("Contraseña", type="password")
            
            st.write("")
            btn_login = st.button("🔐 Iniciar Sesión Segura", type="primary", use_container_width=True)
            
            if btn_login:
                usuario = cdb.verify_credentials(correo_input.strip().lower(), pwd_input)
                if usuario:
                    st.session_state["user"] = usuario
                    cdb.log_auditoria(usuario['correo'], "LOGIN_EXITOSO", "USUARIO", usuario['id'], {"ip": "CloudRun_Client"})
                    st.session_state["flash_msg"] = ("success", f"Bienvenido(a), {usuario['nombre_completo']} ({usuario['rol']})")
                    st.rerun()
                else:
                    st.error("Credenciales incorrectas o cuenta inactiva. Verifique correo y contraseña.")
                    cdb.log_auditoria(correo_input, "LOGIN_FALLIDO", "USUARIO", None, {"intento": "Password erróneo"})

            st.markdown("---")
            st.markdown("**Credenciales de demostración precargadas:**")
            st.caption("• **Ventanilla SSI:** `ssi@cenam.mx` | Contraseña: `Cenam2026*`")
            st.caption("• **AT Dimensional (AT-01):** `at.dimensional@cenam.mx` | Contraseña: `Cenam2026*`")
            st.caption("• **AT Eléctrica (AT-02):** `at.electrica@cenam.mx` | Contraseña: `Cenam2026*`")
            st.caption("• **AT Presión (AT-08):** `at.presion@cenam.mx` | Contraseña: `Cenam2026*`")
            st.caption("• **Administrador:** `admin@cenam.mx` | Contraseña: `Cenam2026*`")
    st.stop()

# ==========================================
# SESIÓN AUTENTICADA: ROLES Y PERMISOS
# ==========================================
user = st.session_state["user"]
rol = user['rol']
clave_area = user['clave_area']

# Cargar Áreas Técnicas
areas_tecnicas = cdb.get_areas_tecnicas()
areas_dict = {a['clave']: a['nombre'] for a in areas_tecnicas}

# Sidebar con datos de sesión
st.sidebar.markdown(f"**Usuario:** {user['nombre_completo']}")
st.sidebar.markdown(f"**Rol Institucional:** `{rol}`")
if clave_area:
    st.sidebar.markdown(f"**Área Asignada:** `{clave_area}` - {areas_dict.get(clave_area, '')}")
st.sidebar.caption("🔒 Sesión Cifrada Activa (TLS 1.3 / AES-256)")
if engine_probe == "POSTGRES":
    st.sidebar.success(f"☁️ Supabase PostgreSQL ({conn_type_probe})", icon="✅")
else:
    st.sidebar.info("💾 Base Local (SQLite Respaldo)", icon="💾")

if rol == "ADMIN":
    vista_admin = st.sidebar.radio("Modo de Visualización (Admin):", ["🏢 Ventanilla Central (SSI)", "🔬 Área Técnica (AT)"])
else:
    vista_admin = None

if st.sidebar.button("🚪 Cerrar Sesión Segura"):
    cdb.log_auditoria(user['correo'], "LOGOUT", "USUARIO", user['id'], {})
    st.session_state["user"] = None
    st.rerun()

st.sidebar.markdown("---")
st.sidebar.caption("Servidor en Google Cloud Run conectado a Base de Datos Centralizada")

# Determinar vista SSI o AT
mostrar_ssi = (rol == "SSI") or (rol == "ADMIN" and vista_admin == "🏢 Ventanilla Central (SSI)")

# ==========================================
# VISTA 1: ROL SSI (VENTANILLA CENTRAL - CS)
# ==========================================
if mostrar_ssi:
    st.title("🏢 Ventanilla Central (SSI) - Nube Segura")
    st.markdown("Gestión integral de solicitudes, cotizaciones consolidadas, programación de fechas por AT y formalización de contratos.")
    
    conn, engine = cdb.get_db_connection()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM sub_solicitudes_at WHERE estado = 'DEVUELTA'")
    devueltas_count = c.fetchone()[0] or 0
    
    c.execute("""
        SELECT COUNT(DISTINCT m.id)
        FROM solicitudes_master m
        JOIN sub_solicitudes_at s ON m.id = s.solicitud_id
        WHERE m.estado IN ('TURNADA', 'EMITIDA')
        GROUP BY m.id
        HAVING COUNT(s.id) = SUM(CASE WHEN s.estado = 'COMPLETADA' THEN 1 ELSE 0 END)
    """)
    cotiz_listas = len(c.fetchall())
    
    c.execute("SELECT COUNT(*) FROM solicitudes_master WHERE estado = 'COTIZACION_ENVIADA'")
    esperando_acep = c.fetchone()[0] or 0
    
    c.execute("SELECT COUNT(DISTINCT s.id) FROM sub_solicitudes_at s WHERE s.estado = 'PROGRAMA_PROPUESTO'")
    prog_propuestas = c.fetchone()[0] or 0
    conn.close()
    
    if devueltas_count > 0:
        st.warning(f"⚠️ **Atención SSI:** Hay **{devueltas_count} solicitud(es) devuelta(s)** por Áreas Técnicas que requieren reasignación.", icon="⚠️")
    if cotiz_listas > 0:
        st.info(f"🔔 **Aviso SSI:** Hay **{cotiz_listas} cotización(es)** listas para consolidar y emitir.", icon="🔔")
    if prog_propuestas > 0:
        st.info(f"📅 **Aviso Programación:** Hay **{prog_propuestas} programa(s) de fechas** propuestos por Laboratorios listos para enviar al cliente.", icon="📅")

    t1, t2, t3, t4, t5, t6 = st.tabs([
        "📝 1. Nueva Solicitud",
        f"⚠️ 2. Devueltas ({devueltas_count})",
        f"🏷️ 3. Emisión Cotización ({cotiz_listas})",
        f"📅 4. Aceptación y Programación ({esperando_acep + prog_propuestas})",
        "📜 5. Contratos y Confirmación",
        "🔍 6. Bitácora Auditoría"
    ])
    
    # TAB 1: NUEVA SOLICITUD
    with t1:
        st.subheader("Captura de Solicitud de Calibración (Formato Solicitud CENAM PR)")
        with st.expander("📥 Carga Rápida desde Formato Oficial o Correo (Cero Transcripción)", expanded=True):
            st.caption("Obtenga automáticamente todos los datos del cliente y sus instrumentos sin transcribir a mano. Puede subir el archivo `.docx` o `.txt` enviado por el cliente o pegar el cuerpo del correo.")
            col_u1, col_u2 = st.columns([1, 1])
            with col_u1:
                up_doc_c = st.file_uploader("Opción A: Subir archivo Solicitud CENAM PR (.docx o .txt):", type=["docx", "txt"], key="up_sol_doc_cloud")
            with col_u2:
                raw_email_text = st.text_area("Opción B: O pegar texto / cuerpo de correo recibido:", height=95, placeholder="SOLICITUD DE COTIZACIÓN DE SERVICIO DE CALIBRACIÓN...\n1. Datos del solicitante...\n2. Información del instrumento...", key="raw_email_input_cloud")
            
            if st.button("✨ Auto-extraer Datos y Llenar Formulario", key="btn_parse_cloud", type="primary", use_container_width=True):
                parsed = None
                if up_doc_c is not None:
                    parsed = parser.parse_solicitud_input(file_source=up_doc_c)
                elif raw_email_text and raw_email_text.strip():
                    parsed = parser.parse_solicitud_input(raw_text=raw_email_text)
                    
                if parsed and (parsed.get("empresa") or parsed.get("instrumentos") or parsed.get("no_solicitud")):
                    st.session_state["parsed_cloud"] = parsed
                    st.session_state["form_v_cloud"] = st.session_state.get("form_v_cloud", 0) + 1
                    inst_count = len(parsed.get("instrumentos", []))
                    st.session_state["flash_msg"] = ("success", f"✨ Datos extraídos exitosamente: Cliente: **{parsed['empresa'] or 'Detectado'}** | **{inst_count} instrumento(s)** clasificados por Área Técnica.")
                    st.rerun()
                else:
                    st.warning("⚠️ No se detectaron datos suficientes en el archivo o texto proporcionado. Verifique que corresponda al formato oficial de Solicitud CENAM PR.")

        parsed_data = st.session_state.get("parsed_cloud", {})
        form_v_cloud = st.session_state.get("form_v_cloud", 0)
        
        with st.form("form_nueva_sol_cloud", clear_on_submit=True):
            st.markdown("#### 1. Datos del Solicitante")
            c1, c2, c3 = st.columns(3)
            with c1:
                cliente = st.text_input("Razón Social / Nombre del Cliente *", value=parsed_data.get("empresa") or "ECOLOGIA INTEGRADA APLICADA", key=f"c_cli_{form_v_cloud}")
                representante = st.text_input("Representante / Contacto", value=parsed_data.get("contacto") or "Ing. Alba Vázquez Espinosa", key=f"c_rep_{form_v_cloud}")
            with c2:
                correo = st.text_input("Correo Electrónico *", value=parsed_data.get("correo") or "alba_ecol@hotmail.com", key=f"c_mail_{form_v_cloud}")
                telefono = st.text_input("Teléfono", value=parsed_data.get("telefono") or "961 61 591 19", key=f"c_tel_{form_v_cloud}")
            with c3:
                rfc = st.text_input("RFC", value=parsed_data.get("rfc") or "EIA050512XYZ", key=f"c_rfc_{form_v_cloud}")
                pais = st.text_input("País de Solicitud *", value=parsed_data.get("pais") or "México", key=f"c_pais_{form_v_cloud}")
                
            st.markdown("---")
            st.markdown("#### 2. Consecutivos Institucionales y Modalidad")
            c_fol1, c_fol2, c_fol3 = st.columns(3)
            with c_fol1:
                next_sol = parsed_data.get("no_solicitud") or cdb.get_next_solicitud_number()
                no_solicitud = st.text_input("No. de Solicitud (Oficial con sufijo PR) *", value=next_sol, key=f"c_sol_{form_v_cloud}")
            with c_fol2:
                next_fol = parsed_data.get("no_folio") or cdb.get_next_folio_number()
                no_folio = st.text_input("No. de Folio (4 dígitos + año + PR) *", value=next_fol, key=f"c_fol_{form_v_cloud}")
            with c_fol3:
                es_in_situ = st.checkbox("¿Es servicio exclusivamente IN SITU (en planta del cliente)?", value=False, key=f"c_insitu_{form_v_cloud}")
                
            es_extranjero = (pais.strip().lower() != "mexico" and pais.strip().lower() != "méxico")
            if es_extranjero:
                st.warning(f"⚠️ Solicitante en el extranjero detectado ({pais}). En términos de la Ley del IVA, el impuesto no aplica si el servicio es aprovechado en su totalidad en el extranjero.")
                aplica_iva = st.checkbox("¿Exentar IVA (0%) para este cliente extranjero?", value=True, key=f"c_iva_{form_v_cloud}")
            else:
                aplica_iva = st.checkbox("Aplica IVA general del 16%", value=True, key=f"c_iva_{form_v_cloud}")
                
            st.markdown("---")
            st.markdown("#### 3. Instrumentos a Calibrar")
            parsed_inst = parsed_data.get("instrumentos", [])
            num_default = len(parsed_inst) if parsed_inst else 2
            num_eq = st.number_input("Cantidad de Instrumentos:", min_value=1, max_value=30, value=num_default, key=f"c_numeq_{form_v_cloud}")
            
            eq_list = []
            for i in range(int(num_eq)):
                p_item = parsed_inst[i] if i < len(parsed_inst) else {}
                st.markdown(f"**Instrumento {i+1}**")
                ce1, ce2, ce3 = st.columns([3, 2, 2])
                with ce1:
                    d_eq = st.text_input(f"Descripción Instrumento {i+1} *", value=p_item.get("descripcion") or ("Detector de fugas acústico" if i==0 else "Multímetro digital 6.5 dígitos"), key=f"c_desc_{i}_{form_v_cloud}")
                    alc_eq = st.text_input(f"Alcance / Puntos requeridos {i+1}", value=p_item.get("intervalo") or ("<= 80 kHz" if i==0 else "100 mV a 1000 V"), key=f"c_alc_{i}_{form_v_cloud}")
                    cert_eq = st.text_input(f"Certificado anterior o No. equipo CENAM {i+1}", value=p_item.get("certificado_anterior") or "", key=f"c_cert_{i}_{form_v_cloud}")
                with ce2:
                    m_eq = st.text_input(f"Marca {i+1}", value=p_item.get("marca") or ("Mesa Engineering" if i==0 else "Fluke"), key=f"c_m_{i}_{form_v_cloud}")
                    mod_eq = st.text_input(f"Modelo {i+1}", value=p_item.get("modelo") or ("2D" if i==0 else "8846A"), key=f"c_mod_{i}_{form_v_cloud}")
                    mag_eq = st.text_input(f"Magnitud {i+1}", value=p_item.get("magnitud") or ("Vibraciones y Acústica" if i==0 else "Eléctrica"), key=f"c_mag_{i}_{form_v_cloud}")
                with ce3:
                    s_eq = st.text_input(f"No. Serie {i+1}", value=p_item.get("serie") or f"SN-{2000+i}", key=f"c_s_{i}_{form_v_cloud}")
                    id_eq = st.text_input(f"Identificación Interna {i+1}", value=p_item.get("id_interno") or f"PR-EQ-{i+1:02d}", key=f"c_id_{i}_{form_v_cloud}")
                    sug_at = p_item.get("clave_area_sugerida") or parser.sugerir_area_por_magnitud_y_texto(mag_eq, d_eq)
                    at_dest = st.selectbox(
                        f"Área Técnica Destino {i+1}",
                        options=list(areas_dict.keys()),
                        format_func=lambda x: f"{x} - {areas_dict[x]}",
                        index=list(areas_dict.keys()).index(sug_at) if sug_at in areas_dict else 0,
                        key=f"c_at_{i}_{form_v_cloud}"
                    )
                cond_eq = st.text_input(f"Condiciones particulares de calibración {i+1} (Opcional)", value=p_item.get("condiciones") or "", key=f"c_cond_{i}_{form_v_cloud}")
                eq_list.append({"num": i+1, "desc": d_eq, "marca": m_eq, "modelo": mod_eq, "serie": s_eq, "alcance": alc_eq, "cert": cert_eq, "mag": mag_eq, "id": id_eq, "cond": cond_eq, "area": at_dest})
                st.divider()
                
            btn_guardar_cloud = st.form_submit_button("🚀 Registrar Solicitud en Nube Segura y Notificar a ATs", type="primary")
            
            if btn_guardar_cloud:
                conn, engine = cdb.get_db_connection()
                c = conn.cursor()
                now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                vig_str = f"{datetime.now().year}-12-31"
                
                c.execute("""
                INSERT INTO solicitudes_master (
                    no_solicitud, no_folio, version, cliente, representante, telefono, correo, rfc, pais,
                    es_extranjero, aplica_iva, fecha_recepcion, fecha_emision, vigencia, estado, es_in_situ
                ) VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'TURNADA', ?)
                """, (
                    no_solicitud, no_folio, cliente, representante, telefono, correo, rfc, pais,
                    1 if es_extranjero else 0, 0 if (es_extranjero and aplica_iva) else (1 if aplica_iva else 0),
                    now_str, datetime.now().strftime("%Y-%m-%d"), vig_str, 1 if es_in_situ else 0
                ))
                sol_master_id = c.lastrowid
                
                areas_unicas = list(set([e['area'] for e in eq_list]))
                sub_map = {}
                for a_c in areas_unicas:
                    c.execute("""
                    INSERT INTO sub_solicitudes_at (solicitud_id, clave_area, estado, fecha_asignacion, fecha_limite_sla)
                    VALUES (?, ?, 'ASIGNADA', ?, ?)
                    """, (sol_master_id, a_c, now_str, (datetime.now() + timedelta(days=3)).strftime("%Y-%m-%d")))
                    sub_map[a_c] = c.lastrowid
                    
                for eq in eq_list:
                    c.execute("""
                    INSERT INTO partidas (
                        sub_solicitud_id, solicitud_id, numero_partida, descripcion_equipo,
                        marca, modelo, no_serie, alcance_solicitado, descripcion_servicio,
                        certificado_anterior, magnitud, id_interno, condiciones_particulares
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        sub_map[eq['area']], sol_master_id, eq['num'], eq['desc'],
                        eq['marca'], eq['modelo'], eq['serie'], eq['alcance'], eq['desc'],
                        eq['cert'], eq['mag'], eq['id'], eq['cond']
                    ))
                conn.commit()
                conn.close()
                
                if "parsed_cloud" in st.session_state:
                    del st.session_state["parsed_cloud"]
                    
                cdb.log_auditoria(user['correo'], "CREAR_SOLICITUD", "SOLICITUD_MASTER", sol_master_id, {"folio": no_folio, "cliente": cliente, "areas": areas_unicas})
                nombres_areas = [f"{a} ({areas_dict.get(a, '')})" for a in areas_unicas]
                st.session_state["flash_msg"] = (
                    "success",
                    f"🚀 Solicitud registrada con Folio **{no_folio}** (Solicitud: **{no_solicitud}**). Se ha turnado a: **{', '.join(nombres_areas)}**. Se ha emitido la notificación en la nube para los CS-AT."
                )
                st.toast(f"Solicitud {no_folio} enviada a ATs", icon="📤")
                st.rerun()

    # TAB 2: SOLICITUDES DEVUELTAS
    with t2:
        st.subheader("Bandeja de Solicitudes Devueltas por Áreas Técnicas (No Corresponde)")
        conn, engine = cdb.get_db_connection()
        c = conn.cursor()
        c.execute("""
            SELECT s.id as sub_id, m.id as master_id, m.no_folio, m.no_solicitud, m.cliente,
                   s.clave_area as area_actual, s.motivo_devolucion, s.area_sugerida, s.fecha_asignacion
            FROM sub_solicitudes_at s
            JOIN solicitudes_master m ON s.solicitud_id = m.id
            WHERE s.estado = 'DEVUELTA'
            ORDER BY s.id DESC
        """)
        devueltas = c.fetchall()
        conn.close()
        
        if not devueltas:
            st.info("No hay solicitudes devueltas pendientes de reasignación. ¡Todo el flujo está en orden!")
        else:
            for d in devueltas:
                with st.expander(f"🔴 Folio: {d['no_folio']} | Solicitud: {d['no_solicitud']} | Cliente: {d['cliente']}", expanded=True):
                    col_d1, col_d2 = st.columns([3, 2])
                    with col_d1:
                        st.markdown(f"**Área que la devolvió:** {d['area_actual']} - {areas_dict.get(d['area_actual'], '')}")
                        st.error(f"**Motivo de Devolución indicado por el AT:**\n{d['motivo_devolucion']}")
                        if d['area_sugerida']:
                            st.info(f"💡 **Área sugerida por el AT:** {d['area_sugerida']} - {areas_dict.get(d['area_sugerida'], '')}")
                    with col_d2:
                        sug_idx = list(areas_dict.keys()).index(d['area_sugerida']) if d['area_sugerida'] in areas_dict else 0
                        nueva_at = st.selectbox(
                            "Reasignar a nueva Área Técnica:",
                            options=list(areas_dict.keys()),
                            format_func=lambda x: f"{x} - {areas_dict[x]}",
                            index=sug_idx,
                            key=f"reasig_cloud_{d['sub_id']}"
                        )
                        if st.button("🔄 Confirmar Reasignación en Nube", key=f"btn_r_c_{d['sub_id']}"):
                            conn, engine = cdb.get_db_connection()
                            c = conn.cursor()
                            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                            c.execute("""
                            UPDATE sub_solicitudes_at
                            SET clave_area = ?, estado = 'ASIGNADA', motivo_devolucion = NULL,
                                area_sugerida = NULL, fecha_asignacion = ?, fecha_limite_sla = ?
                            WHERE id = ?
                            """, (nueva_at, now_str, (datetime.now() + timedelta(days=3)).strftime("%Y-%m-%d"), d['sub_id']))
                            conn.commit()
                            conn.close()
                            
                            cdb.log_auditoria(user['correo'], "REASIGNAR_SOLICITUD", "SUB_SOLICITUD", d['sub_id'], {"folio": d['no_folio'], "nueva_area": nueva_at})
                            st.session_state["flash_msg"] = (
                                "success",
                                f"🔄 Solicitud **{d['no_folio']}** reasignada exitosamente a **{nueva_at} - {areas_dict.get(nueva_at, '')}**. Desaparece de esta bandeja y el nuevo AT ha sido notificado."
                            )
                            st.toast(f"Folio {d['no_folio']} reasignado a {nueva_at}", icon="🔄")
                            st.rerun()

    # TAB 3: EMISIÓN DE COTIZACIÓN
    with t3:
        st.subheader("Consolidación y Emisión de Cotización Oficial / DSNR hacia el Cliente")
        conn, engine = cdb.get_db_connection()
        c = conn.cursor()
        c.execute("""
            SELECT m.id, m.no_folio, m.no_solicitud, m.no_cotizacion, m.cliente, m.representante,
                   m.telefono, m.correo, m.rfc, m.pais, m.aplica_iva, m.fecha_emision, m.vigencia, m.estado,
                   COUNT(s.id) as total_subs,
                   SUM(CASE WHEN s.estado = 'COMPLETADA' THEN 1 ELSE 0 END) as subs_completadas
            FROM solicitudes_master m
            LEFT JOIN sub_solicitudes_at s ON m.id = s.solicitud_id
            WHERE m.estado IN ('TURNADA', 'EMITIDA')
            GROUP BY m.id
            ORDER BY m.id DESC
        """)
        solicitudes = c.fetchall()
        conn.close()
        
        if not solicitudes:
            st.success("🎉 No hay cotizaciones pendientes de emitir. Todas han sido despachadas al cliente.")
        else:
            for s in solicitudes:
                is_ready = (s['total_subs'] > 0 and s['total_subs'] == s['subs_completadas'])
                tag = "✅ LISTA PARA CONSOLIDAR Y ENVIAR" if is_ready else f"⏳ EN PROCESO ({s['subs_completadas']}/{s['total_subs']} áreas terminadas)"
                with st.expander(f"Folio: {s['no_folio']} | Solicitud: {s['no_solicitud']} | {s['cliente']} [{tag}]", expanded=is_ready):
                    conn, engine = cdb.get_db_connection()
                    c = conn.cursor()
                    c.execute("""
                        SELECT p.*, a.nombre as nombre_area
                        FROM partidas p
                        LEFT JOIN sub_solicitudes_at sub ON p.sub_solicitud_id = sub.id
                        LEFT JOIN areas_tecnicas a ON sub.clave_area = a.clave
                        WHERE p.solicitud_id = ?
                        ORDER BY p.numero_partida
                    """, (s['id'],))
                    parts = c.fetchall()
                    conn.close()
                    
                    st.dataframe(pd.DataFrame([{
                        "Part.": p['numero_partida'],
                        "Área": p['nombre_area'],
                        "Equipo": p['descripcion_equipo'],
                        "Marca/Modelo": f"{p['marca'] or ''} {p['modelo'] or ''}",
                        "ID": p['id_interno'] or '',
                        "Servicio": p['descripcion_servicio'] or "Pendiente de cotizar",
                        "Días Hábiles": p['tiempo_dias_habiles'],
                        "Total": f"${float(p['precio_total'] or 0.0):,.2f}",
                        "Estado": "🔴 DSNR" if p['es_no_realizable'] == 1 else "🟢 Realizable"
                    } for p in parts]), use_container_width=True)
                    
                    has_viable = any(p['es_no_realizable'] == 0 for p in parts)
                    has_dsnr = any(p['es_no_realizable'] == 1 for p in parts)
                    
                    col_c1, col_c2, col_c3 = st.columns([2, 2, 3])
                    with col_c1:
                        if not s['no_cotizacion'] and is_ready:
                            next_cot = cdb.get_next_cotizacion_number()
                            if st.button(f"🏷️ Asignar No. Cotización ({next_cot})", key=f"cot_c_{s['id']}"):
                                conn, engine = cdb.get_db_connection()
                                c = conn.cursor()
                                c.execute("""
                                UPDATE solicitudes_master
                                SET no_cotizacion = ?, estado = 'EMITIDA', fecha_emision = ?
                                WHERE id = ?
                                """, (next_cot, datetime.now().strftime("%Y-%m-%d"), s['id']))
                                conn.commit()
                                conn.close()
                                cdb.log_auditoria(user['correo'], "EMITIR_COTIZACION", "SOLICITUD_MASTER", s['id'], {"no_cotizacion": next_cot})
                                st.session_state["flash_msg"] = ("success", f"🏷️ No. de Cotización **{next_cot}** asignado con éxito.")
                                st.rerun()
                        elif s['no_cotizacion']:
                            st.success(f"No. Cotización: **{s['no_cotizacion']}**")
                            
                    with col_c2:
                        os.makedirs("generated_docs", exist_ok=True)
                        if has_viable and s['no_cotizacion']:
                            f_pdf = f"generated_docs/Cotizacion_Cloud_{s['no_folio'].replace('-', '_')}_{s['no_cotizacion']}.pdf"
                            pdf_gen.generate_cotizacion_pdf(dict(s), [dict(p) for p in parts], f_pdf)
                            with open(f_pdf, "rb") as f:
                                st.download_button("📥 Descargar Cotización PDF", f, file_name=f"Cotizacion_{s['no_folio']}.pdf", key=f"dl_c_{s['id']}")
                        if has_dsnr:
                            f_dsnr = f"generated_docs/DSNR_Cloud_{s['no_folio'].replace('-', '_')}.pdf"
                            pdf_gen.generate_dsnr_pdf(dict(s), [dict(p) for p in parts if p['es_no_realizable']==1], "Dirección de Metrología", f_dsnr)
                            with open(f_dsnr, "rb") as f:
                                st.download_button("📄 Descargar DSNR PR PDF", f, file_name=f"DSNR_PR_{s['no_folio']}.pdf", key=f"dl_d_{s['id']}")

                    with col_c3:
                        if s['no_cotizacion'] or (not has_viable and has_dsnr):
                            with st.popover("✉️ Enviar Cotización al Cliente"):
                                st.markdown(f"**Destinatario:** `{s['correo']}`")
                                asunto_mail = f"CENAM - Cotizacion Oficial Folio {s['no_folio']} / Solicitud {s['no_solicitud']}"
                                cuerpo_mail = f"Estimado(a) {s['representante'] or s['cliente']}:%0D%0A%0D%0APor medio de la presente, el Centro Nacional de Metrologia (CENAM) hace entrega formal de la Cotizacion No. {s['no_cotizacion'] or ''} correspondiente a su solicitud con Folio {s['no_folio']}.%0D%0A%0D%0AFavor de revisar el documento PDF adjunto y regresar el formato con las partidas aceptadas marcadas.%0D%0A%0D%0AAtentamente,%0D%0AVentanilla Central de Servicios (SSI)%0D%0ACENAM"
                                mailto_url = f"mailto:{s['correo']}?subject={asunto_mail}&body={cuerpo_mail}"
                                st.markdown(f"[📬 Abrir Correo con Plantilla Oficial]({mailto_url})")
                                if st.button("🚀 Confirmar Envío al Cliente y Pasar a Programación", key=f"btn_send_c_{s['id']}", type="primary"):
                                    conn, engine = cdb.get_db_connection()
                                    c = conn.cursor()
                                    c.execute("UPDATE solicitudes_master SET estado = 'COTIZACION_ENVIADA' WHERE id = ?", (s['id'],))
                                    conn.commit()
                                    conn.close()
                                    cdb.log_auditoria(user['correo'], "ENVIAR_COTIZACION", "SOLICITUD_MASTER", s['id'], {"folio": s['no_folio']})
                                    st.session_state["flash_msg"] = ("success", f"✅ Cotización Folio **{s['no_folio']}** enviada al cliente. Pasa a la fase de Aceptación y Programación.")
                                    st.rerun()

    # TAB 4: ACEPTACIÓN Y PROGRAMACIÓN POR AT
    with t4:
        st.subheader("Gestión de Aceptación y Programación de Fechas por Área Técnica (CS-AT)")
        conn, engine = cdb.get_db_connection()
        c = conn.cursor()
        c.execute("""
            SELECT m.*, COUNT(s.id) as total_subs
            FROM solicitudes_master m
            LEFT JOIN sub_solicitudes_at s ON m.id = s.solicitud_id
            WHERE m.estado IN ('COTIZACION_ENVIADA', 'COTIZACION_ACEPTADA', 'EN_PROGRAMACION', 'PROGRAMA_PROPUESTO', 'REPROGRAMACION')
            GROUP BY m.id
            ORDER BY m.id DESC
        """)
        sol_prog = c.fetchall()
        conn.close()
        
        if not sol_prog:
            st.info("No hay solicitudes activas en fase de aceptación o programación.")
        else:
            for s in sol_prog:
                st_badge = "📬 Esperando Aceptación del Cliente" if s['estado'] == 'COTIZACION_ENVIADA' else f"🗓️ En Programación ({s['estado']})"
                with st.expander(f"Folio: {s['no_folio']} | Cotización: {s['no_cotizacion']} | {s['cliente']} [{st_badge}]", expanded=True):
                    if s['estado'] == 'COTIZACION_ENVIADA':
                        st.markdown("#### Aceptación de Partidas por el Cliente")
                        conn, engine = cdb.get_db_connection()
                        c = conn.cursor()
                        c.execute("SELECT * FROM partidas WHERE solicitud_id = ? AND es_no_realizable = 0 ORDER BY numero_partida", (s['id'],))
                        pts = c.fetchall()
                        conn.close()
                        
                        partidas_sel = {}
                        col_chk = st.columns(min(len(pts), 4) or 1)
                        for idx_p, p in enumerate(pts):
                            with col_chk[idx_p % len(col_chk)]:
                                partidas_sel[p['id']] = st.checkbox(
                                    f"Partida {p['numero_partida']}: {p['descripcion_equipo'][:35]} (${float(p['precio_total'] or 0.0):,.2f})",
                                    value=True,
                                    key=f"c_chk_acep_{p['id']}"
                                )
                        f_acep = st.date_input("Fecha de aceptación por el cliente:", value=date.today(), key=f"c_facep_{s['id']}")
                        if st.button("✅ Confirmar Aceptación y Turnar a Programación con CS-AT", key=f"c_btn_turn_prog_{s['id']}", type="primary"):
                            conn, engine = cdb.get_db_connection()
                            c = conn.cursor()
                            for pid, aceptada in partidas_sel.items():
                                c.execute("UPDATE partidas SET aceptada_cliente = ? WHERE id = ?", (1 if aceptada else 0, pid))
                            c.execute("UPDATE solicitudes_master SET estado = 'EN_PROGRAMACION', fecha_aceptacion_cotizacion = ? WHERE id = ?", (f_acep.strftime("%Y-%m-%d"), s['id']))
                            c.execute("UPDATE sub_solicitudes_at SET estado = 'EN_PROGRAMACION' WHERE solicitud_id = ? AND id IN (SELECT sub_solicitud_id FROM partidas WHERE solicitud_id = ? AND aceptada_cliente = 1)", (s['id'], s['id']))
                            conn.commit()
                            conn.close()
                            cdb.log_auditoria(user['correo'], "ACEPTAR_COTIZACION", "SOLICITUD_MASTER", s['id'], {"folio": s['no_folio']})
                            st.session_state["flash_msg"] = ("success", f"📅 Cotización Folio **{s['no_folio']}** aceptada. Se ha turnado a los CS-AT para programar fechas.")
                            st.rerun()
                    else:
                        st.markdown("#### Propuestas de Programación de Fechas por Área Técnica")
                        conn, engine = cdb.get_db_connection()
                        c = conn.cursor()
                        c.execute("""
                            SELECT sub.*, a.nombre as nombre_area
                            FROM sub_solicitudes_at sub
                            LEFT JOIN areas_tecnicas a ON sub.clave_area = a.clave
                            WHERE sub.solicitud_id = ?
                        """, (s['id'],))
                        subs_prog = c.fetchall()
                        conn.close()
                        
                        for sub in subs_prog:
                            st.markdown(f"**Área Técnica:** `{sub['clave_area']}` - **{sub['nombre_area']}** | Estado: `{sub['estado']}`")
                            conn, engine = cdb.get_db_connection()
                            c = conn.cursor()
                            c.execute("SELECT * FROM partidas WHERE sub_solicitud_id = ? AND aceptada_cliente = 1", (sub['id'],))
                            sub_parts = c.fetchall()
                            conn.close()
                            
                            if sub_parts:
                                p_df = pd.DataFrame([{
                                    "Part.": p['numero_partida'],
                                    "Servicio": p['descripcion_servicio'],
                                    "Recepción Equipo (9:00-16:30)": p['fecha_recepcion_equipo'] or sub['fecha_recepcion_prog'] or 'Pendiente AT',
                                    "Inicio Calibración": p['fecha_inicio_calibracion'] or sub['fecha_inicio_prog'] or 'Pendiente AT',
                                    "Entrega / Fin": p['fecha_entrega_equipo'] or sub['fecha_entrega_prog'] or 'Pendiente AT',
                                    "Límite Aceptación": p['fecha_limite_aceptacion'] or sub['fecha_limite_prog'] or '3 semanas'
                                } for p in sub_parts])
                                st.dataframe(p_df, use_container_width=True)
                                
                                if sub['estado'] in ('PROGRAMA_PROPUESTO', 'PROGRAMA_CONFIRMADO'):
                                    col_p1, col_p2, col_p3 = st.columns([2, 2, 3])
                                    with col_p1:
                                        os.makedirs("generated_docs", exist_ok=True)
                                        prog_pdf_path = f"generated_docs/Programacion_Cloud_{s['no_folio'].replace('-', '_')}_{sub['clave_area']}.pdf"
                                        sol_dict = dict(s)
                                        sub_dict = dict(sub)
                                        parts_list = [dict(p) for p in sub_parts]
                                        tipo_prog = 'IN_SITU' if s['es_in_situ'] else 'CENAM'
                                        pdf_gen.generate_programacion_pdf(sol_dict, sub_dict, parts_list, tipo=tipo_prog, filepath=prog_pdf_path)
                                        with open(prog_pdf_path, "rb") as f:
                                            st.download_button(
                                                f"📄 Descargar Programación PDF ({sub['clave_area']})",
                                                data=f,
                                                file_name=f"Programacion_{s['no_folio']}_{sub['clave_area']}.pdf",
                                                mime="application/pdf",
                                                key=f"c_dl_prog_{sub['id']}"
                                            )
                                    with col_p2:
                                        with st.popover("✉️ Enviar Propuesta de Fechas"):
                                            st.markdown(f"**Destinatario:** `{s['correo']}`")
                                            asunto_p = f"CENAM - Propuesta de Programacion {sub['clave_area']} Folio {s['no_folio']}"
                                            body_p = f"Estimado(a) {s['representante'] or s['cliente']}:%0D%0A%0D%0ALe informamos las fechas programadas para los servicios de calibracion del Area Tecnica {sub['clave_area']}.%0D%0A%0D%0AFavor de revisar el documento de Programacion adjunto para su aceptacion.%0D%0A%0D%0AAtentamente,%0D%0ACoordinador de Servicios (SSI) - CENAM"
                                            mailto_prog = f"mailto:{s['correo']}?subject={asunto_p}&body={body_p}"
                                            st.markdown(f"[📬 Abrir Correo con Propuesta]({mailto_prog})")
                                            if st.button("Confirmar Envío", key=f"c_btn_send_p_{sub['id']}"):
                                                st.toast(f"Propuesta enviada al cliente", icon="✉️")
                                    with col_p3:
                                        with st.popover("🔄 Solicitar Cambio de Fecha (Reprogramación)"):
                                            st.markdown("**Solicitud de Reprogramación hacia CS-AT**")
                                            motivo_rep = st.text_area("Indique fechas solicitadas por el cliente:", key=f"c_mot_rep_{sub['id']}")
                                            if st.button("Turnar a CS-AT", key=f"c_btn_turn_rep_{sub['id']}"):
                                                conn, engine = cdb.get_db_connection()
                                                c = conn.cursor()
                                                c.execute("UPDATE sub_solicitudes_at SET estado = 'REPROGRAMACION', motivo_reprogramacion = ? WHERE id = ?", (motivo_rep, sub['id']))
                                                c.execute("UPDATE solicitudes_master SET estado = 'REPROGRAMACION' WHERE id = ?", (s['id'],))
                                                conn.commit()
                                                conn.close()
                                                cdb.log_auditoria(user['correo'], "SOLICITAR_REPROGRAMACION", "SUB_SOLICITUD", sub['id'], {"motivo": motivo_rep})
                                                st.session_state["flash_msg"] = ("warning", f"🔄 Sub-solicitud turnada al CS-AT de {sub['clave_area']} para reprogramación.")
                                                st.rerun()
                            st.write("")
                            
                        todos_listos = all(sub['estado'] in ('PROGRAMA_PROPUESTO', 'PROGRAMA_CONFIRMADO') for sub in subs_prog)
                        if todos_listos:
                            if st.button("🎉 Cliente Aceptó Programación -> Formalizar Contratos", key=f"c_btn_goto_conf_{s['id']}", type="primary"):
                                conn, engine = cdb.get_db_connection()
                                c = conn.cursor()
                                c.execute("UPDATE solicitudes_master SET estado = 'PROGRAMA_CONFIRMADO' WHERE id = ?", (s['id'],))
                                conn.commit()
                                conn.close()
                                st.session_state["flash_msg"] = ("success", f"📜 Folio {s['no_folio']} listo para formalizar contrato.")
                                st.rerun()

    # TAB 5: CONFIRMACIÓN Y CONTRATOS
    with t5:
        st.subheader("Formalización de Contratos, Retorno de Equipos y Confirmación Definitiva")
        conn, engine = cdb.get_db_connection()
        c = conn.cursor()
        c.execute("SELECT * FROM solicitudes_master WHERE estado IN ('PROGRAMA_CONFIRMADO', 'CONFIRMADA_CONCLUIDA') ORDER BY id DESC")
        sol_conf = c.fetchall()
        conn.close()
        
        if not sol_conf:
            st.info("No hay solicitudes pendientes de formalizar contrato.")
        else:
            for s in sol_conf:
                is_concluida = (s['estado'] == 'CONFIRMADA_CONCLUIDA')
                tag = "🏁 SERVICIO CONFIRMADO Y CONTRATO FORMALIZADO" if is_concluida else "📋 PENDIENTE DE FORMALIZAR"
                with st.expander(f"Folio: {s['no_folio']} | Cotización: {s['no_cotizacion']} | {s['cliente']} [{tag}]", expanded=not is_concluida):
                    c_conf1, c_conf2 = st.columns(2)
                    with c_conf1:
                        st.markdown("#### Configuración de Contrato y Retorno de Equipos")
                        ret_actual = s['modalidad_retorno'] or 'RECOLECCION_CENAM'
                        opciones_ret = {
                            'RECOLECCION_CENAM': 'Opción 1: Mi empresa recogerá el equipo en instalaciones del CENAM',
                            'MENSAJERIA_CLIENTE': 'Opción 2: Mi empresa contratará servicio de mensajería para recolección',
                            'GUIA_PREPAGADA': 'Opción 3: Mi empresa enviará una guía prepagada para el retorno'
                        }
                        nueva_ret = st.radio("Modalidad de Retorno de Equipo:", options=list(opciones_ret.keys()), format_func=lambda x: opciones_ret[x], index=list(opciones_ret.keys()).index(ret_actual), key=f"c_ret_{s['id']}")
                        rep_cenam_actual = s['representante_legal_cenam'] or ""
                        rep_cenam_input = st.text_input("Representante Legal del CENAM (Dejar vacío para firma autógrafa física):", value=rep_cenam_actual, placeholder="Ej. Lic. Nombre del Representante Legal (o en blanco)", key=f"c_rep_{s['id']}")
                        
                        if s['es_in_situ']:
                            dir_planta = st.text_input("Dirección de la planta donde se realizará el servicio:", value=s['direccion_servicio_sitio'] or "", key=f"c_dir_{s['id']}")
                            cond_planta = st.text_input("Condiciones de acceso a planta (EPP, inducción):", value=s['condiciones_acceso_planta'] or "Equipo de protección personal completo", key=f"c_cond_{s['id']}")
                        else:
                            dir_planta = None
                            cond_planta = None
                    with c_conf2:
                        st.markdown("#### Descarga de Contratos y Programaciones por AT")
                        conn, engine = cdb.get_db_connection()
                        c = conn.cursor()
                        c.execute("SELECT sub.*, a.nombre as nombre_area FROM sub_solicitudes_at sub LEFT JOIN areas_tecnicas a ON sub.clave_area = a.clave WHERE sub.solicitud_id = ?", (s['id'],))
                        subs = c.fetchall()
                        conn.close()
                        
                        for sub in subs:
                            conn, engine = cdb.get_db_connection()
                            c = conn.cursor()
                            c.execute("SELECT * FROM partidas WHERE sub_solicitud_id = ? AND aceptada_cliente = 1", (sub['id'],))
                            parts = c.fetchall()
                            conn.close()
                            if parts:
                                os.makedirs("generated_docs", exist_ok=True)
                                pdf_path = f"generated_docs/Contrato_Programacion_Cloud_{s['no_folio'].replace('-', '_')}_{sub['clave_area']}.pdf"
                                sol_d = dict(s)
                                sol_d['modalidad_retorno'] = nueva_ret
                                sol_d['direccion_servicio_sitio'] = dir_planta
                                sol_d['condiciones_acceso_planta'] = cond_planta
                                pdf_gen.generate_programacion_pdf(sol_d, dict(sub), [dict(p) for p in parts], tipo='IN_SITU' if s['es_in_situ'] else 'CENAM', filepath=pdf_path, rep_legal_cenam=rep_cenam_input)
                                with open(pdf_path, "rb") as f:
                                    st.download_button(f"📜 Descargar Contrato y Programación ({sub['clave_area']})", data=f, file_name=f"Contrato_Programacion_{s['no_folio']}_{sub['clave_area']}.pdf", mime="application/pdf", key=f"c_dl_c_{sub['id']}")
                    st.divider()
                    if not is_concluida:
                        if st.button("🏁 Confirmar Servicio, Reservar Laboratorios y Archivar Trámite", key=f"c_btn_fin_all_{s['id']}", type="primary"):
                            conn, engine = cdb.get_db_connection()
                            c = conn.cursor()
                            c.execute("""
                            UPDATE solicitudes_master
                            SET estado = 'CONFIRMADA_CONCLUIDA', modalidad_retorno = ?, representante_legal_cenam = ?,
                                direccion_servicio_sitio = ?, condiciones_acceso_planta = ?, fecha_confirmacion_programa = ?
                            WHERE id = ?
                            """, (nueva_ret, rep_cenam_input, dir_planta, cond_planta, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), s['id']))
                            c.execute("UPDATE sub_solicitudes_at SET estado = 'PROGRAMA_CONFIRMADO' WHERE solicitud_id = ?", (s['id'],))
                            conn.commit()
                            conn.close()
                            cdb.log_auditoria(user['correo'], "CONFIRMAR_SERVICIO", "SOLICITUD_MASTER", s['id'], {"folio": s['no_folio']})
                            st.session_state["flash_msg"] = ("success", f"🏁 ¡Servicio confirmado exitosamente! Folio **{s['no_folio']}**. Se ha notificado a los laboratorios CS-AT para la reserva.")
                            st.rerun()

    # TAB 6: AUDITORÍA
    with t6:
        st.subheader("Bitácora de Auditoría Inmutable (Trazabilidad Total ISO 17025)")
        conn, engine = cdb.get_db_connection()
        c = conn.cursor()
        c.execute("SELECT id, usuario_correo, accion, entidad, registro_id, detalles, fecha FROM bitacora_auditoria ORDER BY id DESC LIMIT 100")
        logs = c.fetchall()
        conn.close()
        if logs:
            st.dataframe(pd.DataFrame([dict(l) for l in logs]), use_container_width=True)
        else:
            st.info("No hay eventos registrados en la bitácora aún.")

# ==========================================
# VISTA 2: ROL ÁREA TÉCNICA (CS-AT)
# ==========================================
else:
    if rol == "ADMIN":
        at_actual = st.sidebar.selectbox("Seleccione Área a evaluar (Admin):", options=list(areas_dict.keys()), format_func=lambda x: f"{x} - {areas_dict[x]}")
    else:
        at_actual = clave_area

    st.title(f"🔬 {at_actual} - {areas_dict.get(at_actual, '')}")
    st.caption(f"Usuario: {user['nombre_completo']} | Rol: CS-AT (Evaluación, Cotización y Programación)")
    
    col_sla1, col_sla2 = st.columns([3, 2])
    with col_sla2:
        st.info("⏱️ **Reglas de Calidad:** 3 días hábiles para cotizar. La fecha de recepción se calcula automáticamente a 2 días hábiles antes de la fecha de inicio.")
    
    at_tab1, at_tab2, at_tab3 = st.tabs(["🔬 1. Cotización Metrológica", "🗓️ 2. Programación de Fechas", "📌 3. Calendario Confirmado"])
    
    # AT PESTAÑA 1: COTIZACIÓN
    with at_tab1:
        conn, engine = cdb.get_db_connection()
        c = conn.cursor()
        c.execute("""
            SELECT s.id as sub_id, m.id as master_id, m.no_folio, m.no_solicitud, m.cliente,
                   m.representante, s.estado, s.fecha_asignacion, s.fecha_limite_sla, m.es_in_situ
            FROM sub_solicitudes_at s
            JOIN solicitudes_master m ON s.solicitud_id = m.id
            WHERE s.clave_area = ? AND s.estado IN ('ASIGNADA', 'EN_CONSULTA')
            ORDER BY s.id DESC
        """, (at_actual,))
        solicitudes_at = c.fetchall()
        conn.close()
        
        if len(solicitudes_at) > 0:
            st.info(f"🔔 **Aviso CS-AT ({at_actual}):** Tiene **{len(solicitudes_at)} solicitud(es) pendiente(s)** de cotización.", icon="🔔")
        
        if not solicitudes_at:
            st.success(f"🎉 No hay cotizaciones pendientes para **{at_actual}**. ¡Bandeja al día!")
        else:
            for sol in solicitudes_at:
                sla_text = get_sla_badge(sol['fecha_asignacion'])
                with st.expander(f"📋 Folio: {sol['no_folio']} | Solicitud: {sol['no_solicitud']} | Cliente: {sol['cliente']} | SLA: {sla_text}", expanded=True):
                    c_act1, c_act2 = st.columns(2)
                    with c_act1:
                        with st.popover("↩️ Devolver a SSI (No Corresponde a mi Área)"):
                            st.markdown("**Devolución inmediata a SSI sin cotizar**")
                            mot_d = st.text_area("Motivo técnico:", key=f"c_mot_{sol['sub_id']}")
                            sug_at = st.selectbox("Área sugerida:", options=[a for a in areas_dict.keys() if a != at_actual], format_func=lambda x: f"{x} - {areas_dict[x]}", key=f"c_sug_{sol['sub_id']}")
                            if st.button("Confirmar Devolución", key=f"c_btn_dev_{sol['sub_id']}"):
                                conn, engine = cdb.get_db_connection()
                                c = conn.cursor()
                                c.execute("UPDATE sub_solicitudes_at SET estado = 'DEVUELTA', motivo_devolucion = ?, area_sugerida = ? WHERE id = ?", (mot_d, sug_at, sol['sub_id']))
                                conn.commit()
                                conn.close()
                                cdb.log_auditoria(user['correo'], "DEVOLVER_SOLICITUD", "SUB_SOLICITUD", sol['sub_id'], {"folio": sol['no_folio'], "motivo": mot_d})
                                st.session_state["flash_msg"] = ("warning", f"↩️ Solicitud Folio **{sol['no_folio']}** devuelta a SSI para reasignación.")
                                st.rerun()
                    with c_act2:
                        with st.popover("👨‍🔬 Consultar Especialista (SLA 3 Días)"):
                            esp_name = st.text_input("Nombre Especialista:", key=f"c_esp_{sol['sub_id']}")
                            esp_preg = st.text_area("Pregunta Metrológica:", key=f"c_preg_{sol['sub_id']}")
                            esp_resp = st.text_area("Respuesta del Especialista (ISO 17025):", key=f"c_resp_{sol['sub_id']}")
                            if st.button("Guardar Evidencia", key=f"c_btn_save_esp_{sol['sub_id']}"):
                                conn, engine = cdb.get_db_connection()
                                c = conn.cursor()
                                c.execute("""
                                INSERT INTO consultas_especialistas (sub_solicitud_id, especialista_nombre, pregunta, respuesta, fecha_consulta, fecha_respuesta, estado)
                                VALUES (?, ?, ?, ?, ?, ?, 'CONTESTADA')
                                """, (sol['sub_id'], esp_name, esp_preg, esp_resp, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                                c.execute("UPDATE sub_solicitudes_at SET estado = 'EN_CONSULTA' WHERE id = ?", (sol['sub_id'],))
                                conn.commit()
                                conn.close()
                                cdb.log_auditoria(user['correo'], "CONSULTA_ESPECIALISTA", "SUB_SOLICITUD", sol['sub_id'], {"especialista": esp_name})
                                st.success("Evidencia archivada con éxito.")
                                st.rerun()
                                
                    st.markdown("---")
                    st.markdown("### Partidas Asignadas para Cotización")
                    conn, engine = cdb.get_db_connection()
                    c = conn.cursor()
                    c.execute("SELECT * FROM partidas WHERE sub_solicitud_id = ? ORDER BY numero_partida", (sol['sub_id'],))
                    partidas = c.fetchall()
                    servicios_area = cdb.get_servicios_por_area(at_actual)
                    serv_map = {s['clave_servicio']: f"{s['supuesto'][:90]}... (${s['costo']:,.2f})" for s in servicios_area}
                    conn.close()
                    
                    for p in partidas:
                        st.markdown(f"**Partida {p['numero_partida']}: {p['descripcion_equipo']}**")
                        st.caption(f"Marca: `{p['marca']}` | Modelo: `{p['modelo']}` | Serie: `{p['no_serie']}` | ID Interno: `{p['id_interno']}` | Cert. anterior: `{p['certificado_anterior'] or 'N/A'}`")
                        
                        col_p1, col_p2, col_p3 = st.columns([4, 2, 2])
                        with col_p1:
                            modo_p = st.radio("Modalidad:", ["Catálogo Oficial de mi Área", "Partida Manual Libre", "Servicio No Realizable (DSNR)"], horizontal=True, key=f"c_modop_{p['id']}")
                            if modo_p == "Catálogo Oficial de mi Área":
                                if not servicios_area:
                                    st.warning("No hay servicios catalogados para esta área.")
                                    s_sel = None
                                    p_costo = 0.0
                                    p_dias = 5
                                    desc_fin = ""
                                else:
                                    s_sel = st.selectbox("Servicio del Catálogo:", options=list(serv_map.keys()), format_func=lambda x: serv_map[x], key=f"c_ssel_{p['id']}")
                                    s_obj = next((s for s in servicios_area if s['clave_servicio'] == s_sel), None)
                                    p_costo = s_obj['costo'] if s_obj else 0.0
                                    p_dias = s_obj['dias_habiles_defecto'] if s_obj else 5
                                    desc_fin = s_obj['supuesto'] if s_obj else ""
                                motivo_d = None
                                es_no = 0
                                es_man = 0
                            elif modo_p == "Partida Manual Libre":
                                desc_fin = st.text_input("Descripción personalizada:", value=p['descripcion_servicio'] or "", key=f"c_mdesc_{p['id']}")
                                p_costo = st.number_input("Precio Unitario ($ M.N.):", value=float(p['precio_unitario'] or 0.0), key=f"c_mcost_{p['id']}")
                                p_dias = 5
                                s_sel = "MANUAL"
                                motivo_d = None
                                es_no = 0
                                es_man = 1
                            else:
                                s_sel = "DSNR"
                                desc_fin = p['descripcion_equipo']
                                p_costo = 0.0
                                p_dias = 0
                                es_no = 1
                                es_man = 0
                                motivo_d = st.text_area("Motivo DSNR y Canalización:", value="Lamentamos informarle que este servicio no se realiza en el CENAM. Favor de canalizar este servicio a laboratorios secundarios, actualmente hay muchos que están acreditados.", key=f"c_dsnrtxt_{p['id']}")

                        with col_p2:
                            if es_no == 0:
                                cant = st.number_input("Cantidad/Puntos:", min_value=1, value=int(p['cantidad'] or 1), key=f"c_cant_{p['id']}")
                                dias_c = st.number_input("Días Hábiles (Tiempo cal.):", min_value=1, value=int(p['tiempo_dias_habiles'] or p_dias), key=f"c_dias_{p['id']}")
                            else:
                                cant = 1
                                dias_c = 0
                        with col_p3:
                            tot = p_costo * cant
                            if es_no == 0:
                                st.metric("Total Partida", f"${tot:,.2f}")
                            else:
                                st.error("No Realizable (DSNR)")
                            if st.button("💾 Guardar Partida", key=f"c_savep_{p['id']}"):
                                conn, engine = cdb.get_db_connection()
                                c = conn.cursor()
                                c.execute("""
                                UPDATE partidas
                                SET es_manual = ?, clave_servicio = ?, descripcion_servicio = ?,
                                    tiempo_dias_habiles = ?, cantidad = ?, precio_unitario = ?,
                                    precio_total = ?, es_no_realizable = ?, motivo_dsnr = ?
                                WHERE id = ?
                                """, (es_man, s_sel, desc_fin, dias_c, cant, p_costo, tot, es_no, motivo_d, p['id']))
                                conn.commit()
                                conn.close()
                                cdb.log_auditoria(user['correo'], "ACTUALIZAR_PARTIDA", "PARTIDA", p['id'], {"servicio": s_sel, "total": tot})
                                st.success("Partida guardada.")
                                st.rerun()
                        st.divider()

                    if st.button("🏁 Aprobar y Regresar Cotización a SSI", key=f"c_fin_{sol['sub_id']}", type="primary"):
                        conn, engine = cdb.get_db_connection()
                        c = conn.cursor()
                        c.execute("UPDATE sub_solicitudes_at SET estado = 'COMPLETADA' WHERE id = ?", (sol['sub_id'],))
                        conn.commit()
                        conn.close()
                        cdb.log_auditoria(user['correo'], "COMPLETAR_SUB_SOLICITUD", "SUB_SOLICITUD", sol['sub_id'], {"folio": sol['no_folio']})
                        st.session_state["flash_msg"] = ("success", f"✅ ¡Cotización Folio **{sol['no_folio']}** enviada a SSI exitosamente!")
                        st.rerun()

    # AT PESTAÑA 2: PROGRAMACIÓN DE FECHAS
    with at_tab2:
        st.subheader("Programación de Fechas de Laboratorio (Servicios con Cotización Aceptada)")
        st.caption("Asigne las fechas de inicio, entrega y límite. La fecha de recepción se calcula automáticamente a 2 días hábiles antes del inicio.")
        
        conn, engine = cdb.get_db_connection()
        c = conn.cursor()
        c.execute("""
            SELECT s.id as sub_id, m.id as master_id, m.no_folio, m.no_solicitud, m.no_cotizacion,
                   m.cliente, m.es_in_situ, s.estado, s.motivo_reprogramacion
            FROM sub_solicitudes_at s
            JOIN solicitudes_master m ON s.solicitud_id = m.id
            WHERE s.clave_area = ? AND s.estado IN ('EN_PROGRAMACION', 'REPROGRAMACION')
            ORDER BY s.id DESC
        """, (at_actual,))
        pendientes_prog = c.fetchall()
        conn.close()
        
        if not pendientes_prog:
            st.success(f"🎉 No hay servicios pendientes de programar fechas para **{at_actual}**.")
        else:
            for sp in pendientes_prog:
                is_rep = (sp['estado'] == 'REPROGRAMACION')
                b_color = "🔴 REPROGRAMACIÓN SOLICITADA POR CLIENTE" if is_rep else "📅 PROGRAMACIÓN PENDIENTE"
                
                with st.expander(f"Folio: {sp['no_folio']} | Cotización: {sp['no_cotizacion']} | {sp['cliente']} [{b_color}]", expanded=True):
                    if is_rep and sp['motivo_reprogramacion']:
                        st.warning(f"⚠️ **Motivo de reprogramación indicado por el cliente:**\n{sp['motivo_reprogramacion']}", icon="⚠️")
                        
                    conn, engine = cdb.get_db_connection()
                    c = conn.cursor()
                    c.execute("SELECT * FROM partidas WHERE sub_solicitud_id = ? AND aceptada_cliente = 1 ORDER BY numero_partida", (sp['sub_id'],))
                    partidas_prog = c.fetchall()
                    conn.close()
                    
                    st.markdown("#### Asignación de Calendario de Laboratorio por Partida")
                    
                    fechas_por_partida = {}
                    for p in partidas_prog:
                        st.markdown(f"**Partida {p['numero_partida']}: {p['descripcion_equipo']}** (Tiempo cal. cotizado: **{p['tiempo_dias_habiles']} días hábiles**)")
                        col_f1, col_f2, col_f3, col_f4 = st.columns(4)
                        with col_f2:
                            def_ini = date.today() + timedelta(days=14)
                            if p['fecha_inicio_calibracion']:
                                try: def_ini = datetime.strptime(p['fecha_inicio_calibracion'], "%Y-%m-%d").date()
                                except: pass
                            f_ini = st.date_input("Fecha Inicio Calibración *:", value=def_ini, key=f"c_fini_{p['id']}")
                            
                            # Sincronización automática de recepción (-2 días hábiles)
                            prev_ini_k = f"c_prev_fini_{p['id']}"
                            if prev_ini_k in st.session_state and st.session_state[prev_ini_k] != f_ini:
                                f_ini_dt = datetime.combine(f_ini, datetime.min.time())
                                st.session_state[f"c_frec_{p['id']}"] = cdb.restar_dias_habiles(f_ini_dt, 2).date()
                                d_h = int(p['tiempo_dias_habiles'] or 5)
                                st.session_state[f"c_ffin_{p['id']}"] = cdb.sumar_dias_habiles(f_ini_dt, d_h).date()
                            st.session_state[prev_ini_k] = f_ini
                            
                        with col_f1:
                            f_ini_dt = datetime.combine(f_ini, datetime.min.time())
                            f_rec_auto = cdb.restar_dias_habiles(f_ini_dt, 2).date()
                            if p['fecha_recepcion_equipo']:
                                try: f_rec_auto = datetime.strptime(p['fecha_recepcion_equipo'], "%Y-%m-%d").date()
                                except: pass
                            f_rec = st.date_input("Fecha Recepción (-2 días hábiles):", value=f_rec_auto, key=f"c_frec_{p['id']}")
                        with col_f3:
                            dias_h = int(p['tiempo_dias_habiles'] or 5)
                            f_fin_auto = cdb.sumar_dias_habiles(f_ini_dt, dias_h).date()
                            if p['fecha_entrega_equipo']:
                                try: f_fin_auto = datetime.strptime(p['fecha_entrega_equipo'], "%Y-%m-%d").date()
                                except: pass
                            f_fin = st.date_input("Fecha Entrega / Fin *:", value=f_fin_auto, key=f"c_ffin_{p['id']}")
                        with col_f4:
                            f_lim_auto = date.today() + timedelta(days=21)
                            if p['fecha_limite_aceptacion']:
                                try: f_lim_auto = datetime.strptime(p['fecha_limite_aceptacion'], "%Y-%m-%d").date()
                                except: pass
                            f_lim = st.date_input("Fecha Límite Aceptación:", value=f_lim_auto, key=f"c_flim_{p['id']}")
                            
                        fechas_por_partida[p['id']] = {
                            "recepcion": f_rec.strftime("%Y-%m-%d"),
                            "inicio": f_ini.strftime("%Y-%m-%d"),
                            "entrega": f_fin.strftime("%Y-%m-%d"),
                            "limite": f_lim.strftime("%Y-%m-%d")
                        }
                        st.write("")
                        
                    if st.button("🚀 Enviar Fechas Programadas a SSI", key=f"c_btn_send_p_{sp['sub_id']}", type="primary"):
                        conn, engine = cdb.get_db_connection()
                        c = conn.cursor()
                        for pid, f_dict in fechas_por_partida.items():
                            c.execute("""
                            UPDATE partidas
                            SET fecha_recepcion_equipo = ?, fecha_inicio_calibracion = ?,
                                fecha_fin_calibracion = ?, fecha_entrega_equipo = ?, fecha_limite_aceptacion = ?
                            WHERE id = ?
                            """, (f_dict['recepcion'], f_dict['inicio'], f_dict['entrega'], f_dict['entrega'], f_dict['limite'], pid))
                            
                        first_f = list(fechas_por_partida.values())[0] if fechas_por_partida else {}
                        c.execute("""
                        UPDATE sub_solicitudes_at
                        SET estado = 'PROGRAMA_PROPUESTO', motivo_reprogramacion = NULL,
                            fecha_recepcion_prog = ?, fecha_inicio_prog = ?,
                            fecha_entrega_prog = ?, fecha_limite_prog = ?
                        WHERE id = ?
                        """, (
                            first_f.get('recepcion'), first_f.get('inicio'),
                            first_f.get('entrega'), first_f.get('limite'),
                            sp['sub_id']
                        ))
                        c.execute("UPDATE solicitudes_master SET estado = 'PROGRAMA_PROPUESTO' WHERE id = ?", (sp['master_id'],))
                        conn.commit()
                        conn.close()
                        
                        cdb.log_auditoria(user['correo'], "PROGRAMAR_FECHAS", "SUB_SOLICITUD", sp['sub_id'], {"folio": sp['no_folio']})
                        st.session_state["flash_msg"] = ("success", f"🗓️ ¡Fechas programadas para Folio **{sp['no_folio']}** enviadas a SSI con éxito!")
                        st.rerun()

    # AT PESTAÑA 3: CALENDARIO CONFIRMADO
    with at_tab3:
        st.subheader("Servicios Confirmados y Reservas en Laboratorio")
        conn, engine = cdb.get_db_connection()
        c = conn.cursor()
        c.execute("""
            SELECT s.id as sub_id, m.no_folio, m.no_cotizacion, m.cliente,
                   s.fecha_recepcion_prog, s.fecha_inicio_prog, s.fecha_entrega_prog
            FROM sub_solicitudes_at s
            JOIN solicitudes_master m ON s.solicitud_id = m.id
            WHERE s.clave_area = ? AND s.estado = 'PROGRAMA_CONFIRMADO'
            ORDER BY s.fecha_inicio_prog ASC
        """, (at_actual,))
        confirmados = c.fetchall()
        conn.close()
        
        if not confirmados:
            st.info("Aún no hay servicios confirmados en el calendario de este laboratorio.")
        else:
            st.dataframe(pd.DataFrame([{
                "Folio": r['no_folio'],
                "Cotización": r['no_cotizacion'],
                "Cliente": r['cliente'],
                "Fecha Recepción": r['fecha_recepcion_prog'],
                "Fecha Inicio": r['fecha_inicio_prog'],
                "Fecha Entrega": r['fecha_entrega_prog'],
                "Estado": "🔒 RESERVA CONFIRMADA"
            } for r in confirmados]), use_container_width=True)
