import re
import os
import io
import zipfile
import xml.etree.ElementTree as ET

def extract_text_from_docx(file_source):
    """
    Extrae texto plano preservando orden de párrafos y celdas de un archivo DOCX oficial de CENAM.
    file_source puede ser una ruta (str), bytes, o un objeto tipo stream (BytesIO / UploadedFile).
    No requiere librerías externas (utiliza zipfile y xml.etree.ElementTree estándar de Python).
    """
    if file_source is None:
        return ""
    
    stream = file_source
    if isinstance(file_source, (str, os.PathLike)):
        with open(file_source, 'rb') as f:
            stream = io.BytesIO(f.read())
    elif isinstance(file_source, bytes):
        stream = io.BytesIO(file_source)
    elif hasattr(file_source, 'read'):
        content = file_source.read()
        if hasattr(file_source, 'seek'):
            try:
                file_source.seek(0)
            except Exception:
                pass
        stream = io.BytesIO(content)

    try:
        with zipfile.ZipFile(stream) as z:
            xml_content = z.read('word/document.xml')
        tree = ET.fromstring(xml_content)
        paragraphs = []
        for p in tree.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p'):
            texts = [t.text for t in p.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t') if t.text]
            if texts:
                paragraphs.append(''.join(texts))
        return '\n'.join(paragraphs)
    except Exception as e:
        return ""

def sugerir_area_por_magnitud_y_texto(magnitud, descripcion):
    """Determina la clave de Área Técnica (AT-01 a AT-14) según magnitud y descripción."""
    mag = (magnitud or "").strip().lower()
    desc = (descripcion or "").strip().lower()
    t = f"{mag} {desc}"
    
    if any(k in t for k in ["dimensional", "longitud", "bloque", "cmm", "rugosi", "esfera", "redondez", "vernier", "micrometro", "regla", "reticula", "retícula", "angul"]):
        return "AT-01" # Dimensional
    elif any(k in t for k in ["electr", "eléctr", "multimetro", "resistor", "capacit", "induct", "zener", "volt", "corriente", "potencia"]):
        return "AT-02" # Eléctrica
    elif any(k in t for k in ["radiofrecuencia", "rf", "coaxial", "atenuador", "antena", "dispersion", "teslametro", "alta frecuencia"]):
        return "AT-03" # Radiofrecuencia
    elif any(k in t for k in ["tiempo", "frecuencia", "reloj", "oscilador", "frecuencimetro"]):
        return "AT-04" # Tiempo y Frecuencia
    elif any(k in t for k in ["termo", "temperatura", "humedad", "pirometro", "termopar", "rocio", "rocío"]):
        return "AT-05" # Termometría
    elif any(k in t for k in ["optica", "óptica", "fotometria", "radiometria", "luxometro", "espectro", "laser", "iluminancia", "lampara", "lámpara"]):
        return "AT-06" # Óptica y Radiometría
    elif any(k in t for k in ["masa", "pesa", "balanza", "densidad", "densimetro", "báscula"]):
        return "AT-07" # Masa y Densidad
    elif any(k in t for k in ["presion", "presión", "fuerza", "manometro", "torquimetro", "celda"]):
        return "AT-08" # Fuerza y Presión
    elif any(k in t for k in ["flujo", "volumen", "caudal", "volumetrico", "pipeta", "matraz", "gas"]):
        return "AT-09" # Flujo y Volumen
    elif any(k in t for k in ["acustica", "acústica", "vibracion", "vibración", "acelerometro", "sonometro", "microfono"]):
        return "AT-10" # Vibraciones y Acústica
    elif any(k in t for k in ["dureza", "durometro", "impacto", "charpy", "brinell", "rockwell", "vickers"]):
        return "AT-11" # Dureza y Ensayos Mecánicos
    elif any(k in t for k in ["quimica", "química", "cromatografia", "espectrometria", "material de referencia", "gas patron"]):
        return "AT-12" # Metrología Química
    elif any(k in t for k in ["fisicoquimica", "fisicoquímica", "ph", "conductividad", "viscosidad", "electrolit"]):
        return "AT-13" # Fisicoquímica
    elif any(k in t for k in ["in situ", "sitio", "planta", "campo", "en sitio"]):
        return "AT-14" # Servicios In Situ
    return "AT-01"

def parse_solicitud_text(text):
    """
    Analiza y extrae la información estructurada del formato Solicitud CENAM PR
    ya sea desde el cuerpo de un correo o texto pegado.
    """
    data = {
        "no_solicitud": None,
        "no_folio": None,
        "contacto": "",
        "empresa": "",
        "telefono": "",
        "rfc": "",
        "pais": "México",
        "correo": "",
        "instrumentos": []
    }
    
    if not text or not isinstance(text, str):
        return data

    # 1. Extraer Solicitud y Folio si vienen en el encabezado
    m_sol = re.search(r"(?:No\.?\s*de\s*solicitud|Solicitud)\s*[:\.]?\s*([0-9A-Za-z_-]*PR|[0-9]{4,})", text, re.IGNORECASE)
    if m_sol:
        data["no_solicitud"] = m_sol.group(1).strip()
        
    m_fol = re.search(r"(?:No\.?\s*de\s*folio|Folio)\s*[:\.]?\s*([0-9A-Za-z_-]+PR|[0-9]+-[0-9]+[A-Za-z]*)", text, re.IGNORECASE)
    if m_fol:
        data["no_folio"] = m_fol.group(1).strip()
        
    # 2. Datos del solicitante
    m_cont = re.search(r"Nombre del contacto\s*:\s*(.+)", text, re.IGNORECASE)
    if m_cont:
        data["contacto"] = m_cont.group(1).strip()
        
    m_emp = re.search(r"Nombre de la empresa\s*:\s*(.+)", text, re.IGNORECASE)
    if m_emp:
        data["empresa"] = m_emp.group(1).strip()
        
    m_tel = re.search(r"Tel[eé]fono\s*:\s*(.+)", text, re.IGNORECASE)
    if m_tel:
        data["telefono"] = m_tel.group(1).strip()
        
    m_rfc = re.search(r"RFC\s*:\s*(.+)", text, re.IGNORECASE)
    if m_rfc:
        data["rfc"] = m_rfc.group(1).strip()
        
    m_pais = re.search(r"Pa[ií]s\s*:\s*(.+)", text, re.IGNORECASE)
    if m_pais:
        data["pais"] = m_pais.group(1).strip()
        
    m_mail = re.search(r"Correo electr[oó]nico\s*:\s*(.+)", text, re.IGNORECASE)
    if m_mail:
        data["correo"] = m_mail.group(1).strip()

    # 3. Instrumentos
    # Separar por "Descripción del instrumento:"
    parts = re.split(r"(?:^|\n)\s*Descripci[oó]n del instrumento\s*:\s*", text, flags=re.IGNORECASE)
    if len(parts) > 1:
        for p in parts[1:]:
            lines = p.strip().split("\n")
            desc = lines[0].strip()
            # Si contiene pie de página final, limpiarlo
            if "Agradecemos proporcionar la información" in desc:
                continue
                
            def extract_val(pattern):
                m = re.search(pattern, p, re.IGNORECASE)
                if m:
                    val = m.group(1).strip()
                    # Cortar si topa con el pie de página
                    if "Agradecemos proporcionar la información" in val:
                        val = val.split("Agradecemos proporcionar")[0].strip()
                    return val
                return ""
                
            cert = extract_val(r"Certificado anterior[^:\n]*:\s*(.*)")
            marca = extract_val(r"Marca\s*:\s*(.*)")
            modelo = extract_val(r"Modelo\s*:\s*(.*)")
            serie = extract_val(r"N[uú]mero de serie\s*:\s*(.*)")
            magnitud = extract_val(r"Magnitud a calibrar\s*:\s*(.*)")
            intervalo = extract_val(r"Intervalo[^:\n]*:\s*(.*)")
            exactitud = extract_val(r"Exactitud[^:\n]*:\s*(.*)")
            id_interno = extract_val(r"Identificaci[oó]n interna[^:\n]*:\s*(.*)")
            condiciones = extract_val(r"Caracter[ií]sticas especiales[^:\n]*:\s*(.*)")
            
            sug_area = sugerir_area_por_magnitud_y_texto(magnitud, desc)
            
            data["instrumentos"].append({
                "descripcion": desc,
                "certificado_anterior": cert,
                "marca": marca,
                "modelo": modelo,
                "serie": serie,
                "magnitud": magnitud,
                "intervalo": intervalo,
                "exactitud": exactitud,
                "id_interno": id_interno,
                "condiciones": condiciones,
                "clave_area_sugerida": sug_area
            })
            
    return data

def parse_solicitud_docx(file_source):
    """Extrae el texto de un archivo docx y lo estructura."""
    text = extract_text_from_docx(file_source)
    return parse_solicitud_text(text)

def parse_solicitud_input(raw_text=None, file_source=None):
    """
    Función de entrada unificada: analiza ya sea texto directo o un archivo DOCX/TXT.
    """
    if file_source is not None:
        name = getattr(file_source, 'name', '') or (file_source if isinstance(file_source, str) else '')
        if name.lower().endswith('.docx'):
            return parse_solicitud_docx(file_source)
        elif name.lower().endswith('.txt'):
            try:
                if hasattr(file_source, 'read'):
                    txt = file_source.read().decode('utf-8', errors='ignore')
                    if hasattr(file_source, 'seek'):
                        file_source.seek(0)
                    return parse_solicitud_text(txt)
                elif isinstance(file_source, str) and os.path.exists(file_source):
                    with open(file_source, 'r', encoding='utf-8', errors='ignore') as f:
                        return parse_solicitud_text(f.read())
            except Exception:
                pass

    if raw_text:
        return parse_solicitud_text(raw_text)
        
    return parse_solicitud_text("")

