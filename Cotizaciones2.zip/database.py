import sqlite3
import csv
import os
import re
from datetime import datetime, timedelta

DB_PATH = os.path.abspath("cotizaciones_cenam.db")
DATA_DIR = os.path.abspath("data")

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    c = conn.cursor()
    
    # Enable foreign keys
    c.execute("PRAGMA foreign_keys = ON;")
    
    # 1. Areas Tecnicas
    c.execute("""
    CREATE TABLE IF NOT EXISTS areas_tecnicas (
        clave TEXT PRIMARY KEY,
        nombre TEXT NOT NULL
    );
    """)
    
    # 2. Catalogo de Servicios
    c.execute("""
    CREATE TABLE IF NOT EXISTS catalogo_servicios (
        clave_servicio TEXT PRIMARY KEY,
        clave_area TEXT NOT NULL,
        nombre_tramite TEXT,
        supuesto TEXT NOT NULL,
        alcance TEXT,
        observaciones TEXT,
        costo REAL NOT NULL,
        fundamento_juridico TEXT,
        es_in_situ TEXT DEFAULT 'NO',
        dias_habiles_defecto INTEGER DEFAULT 5,
        FOREIGN KEY (clave_area) REFERENCES areas_tecnicas (clave)
    );
    """)
    
    # 3. Solicitudes Master
    c.execute("""
    CREATE TABLE IF NOT EXISTS solicitudes_master (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        no_solicitud TEXT UNIQUE NOT NULL,
        no_folio TEXT UNIQUE NOT NULL,
        no_cotizacion TEXT,
        version INTEGER DEFAULT 1,
        cliente TEXT NOT NULL,
        representante TEXT,
        telefono TEXT,
        correo TEXT,
        rfc TEXT,
        pais TEXT DEFAULT 'México',
        es_extranjero INTEGER DEFAULT 0,
        aplica_iva INTEGER DEFAULT 1,
        fecha_recepcion TEXT NOT NULL,
        fecha_emision TEXT,
        vigencia TEXT,
        estado TEXT DEFAULT 'TURNADA',
        es_in_situ INTEGER DEFAULT 0,
        representante_legal_cenam TEXT,
        vigencia_programacion TEXT DEFAULT '3 semanas',
        modalidad_retorno TEXT,
        direccion_servicio_sitio TEXT,
        condiciones_acceso_planta TEXT,
        fecha_aceptacion_cotizacion TEXT,
        fecha_confirmacion_programa TEXT
    );
    """)
    
    # 4. Sub-solicitudes asignadas a ATs
    c.execute("""
    CREATE TABLE IF NOT EXISTS sub_solicitudes_at (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        solicitud_id INTEGER NOT NULL,
        clave_area TEXT NOT NULL,
        estado TEXT DEFAULT 'ASIGNADA',
        motivo_devolucion TEXT,
        area_sugerida TEXT,
        fecha_asignacion TEXT NOT NULL,
        fecha_limite_sla TEXT NOT NULL,
        fecha_recepcion_prog TEXT,
        fecha_inicio_prog TEXT,
        fecha_entrega_prog TEXT,
        fecha_limite_prog TEXT,
        motivo_reprogramacion TEXT,
        FOREIGN KEY (solicitud_id) REFERENCES solicitudes_master (id) ON DELETE CASCADE,
        FOREIGN KEY (clave_area) REFERENCES areas_tecnicas (clave)
    );
    """)
    
    # 5. Partidas
    c.execute("""
    CREATE TABLE IF NOT EXISTS partidas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sub_solicitud_id INTEGER,
        solicitud_id INTEGER NOT NULL,
        numero_partida INTEGER NOT NULL,
        descripcion_equipo TEXT NOT NULL,
        marca TEXT,
        modelo TEXT,
        no_serie TEXT,
        id_interno TEXT,
        alcance_solicitado TEXT,
        certificado_anterior TEXT,
        magnitud TEXT,
        exactitud_clase TEXT,
        condiciones_particulares TEXT,
        es_manual INTEGER DEFAULT 0,
        clave_servicio TEXT,
        descripcion_servicio TEXT,
        tiempo_dias_habiles INTEGER DEFAULT 5,
        cantidad INTEGER DEFAULT 1,
        precio_unitario REAL DEFAULT 0.0,
        precio_total REAL DEFAULT 0.0,
        es_no_realizable INTEGER DEFAULT 0,
        motivo_dsnr TEXT,
        aceptada_cliente INTEGER DEFAULT 1,
        fecha_recepcion_equipo TEXT,
        fecha_inicio_calibracion TEXT,
        fecha_fin_calibracion TEXT,
        fecha_entrega_equipo TEXT,
        fecha_entrega_resultados TEXT,
        fecha_limite_aceptacion TEXT,
        FOREIGN KEY (sub_solicitud_id) REFERENCES sub_solicitudes_at (id) ON DELETE SET NULL,
        FOREIGN KEY (solicitud_id) REFERENCES solicitudes_master (id) ON DELETE CASCADE
    );
    """)
    
    # 6. Consultas a Especialistas
    c.execute("""
    CREATE TABLE IF NOT EXISTS consultas_especialistas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sub_solicitud_id INTEGER NOT NULL,
        especialista_nombre TEXT NOT NULL,
        pregunta TEXT NOT NULL,
        respuesta TEXT,
        fecha_consulta TEXT NOT NULL,
        fecha_respuesta TEXT,
        estado TEXT DEFAULT 'PENDIENTE',
        FOREIGN KEY (sub_solicitud_id) REFERENCES sub_solicitudes_at (id) ON DELETE CASCADE
    );
    """)
    
    conn.commit()
    
    # Migraciones para agregar columnas si la base de datos ya existía
    def add_col_if_missing(table, col_name, col_type):
        c.execute(f"PRAGMA table_info({table});")
        cols = [r[1] for r in c.fetchall()]
        if col_name not in cols:
            try:
                c.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type};")
            except Exception:
                pass

    # Columnas en solicitudes_master
    add_col_if_missing("solicitudes_master", "representante_legal_cenam", "TEXT")
    add_col_if_missing("solicitudes_master", "vigencia_programacion", "TEXT DEFAULT '3 semanas'")
    add_col_if_missing("solicitudes_master", "modalidad_retorno", "TEXT")
    add_col_if_missing("solicitudes_master", "direccion_servicio_sitio", "TEXT")
    add_col_if_missing("solicitudes_master", "condiciones_acceso_planta", "TEXT")
    add_col_if_missing("solicitudes_master", "fecha_aceptacion_cotizacion", "TEXT")
    add_col_if_missing("solicitudes_master", "fecha_confirmacion_programa", "TEXT")

    # Columnas en sub_solicitudes_at
    add_col_if_missing("sub_solicitudes_at", "fecha_recepcion_prog", "TEXT")
    add_col_if_missing("sub_solicitudes_at", "fecha_inicio_prog", "TEXT")
    add_col_if_missing("sub_solicitudes_at", "fecha_entrega_prog", "TEXT")
    add_col_if_missing("sub_solicitudes_at", "fecha_limite_prog", "TEXT")
    add_col_if_missing("sub_solicitudes_at", "motivo_reprogramacion", "TEXT")

    # Columnas en partidas
    add_col_if_missing("partidas", "certificado_anterior", "TEXT")
    add_col_if_missing("partidas", "magnitud", "TEXT")
    add_col_if_missing("partidas", "exactitud_clase", "TEXT")
    add_col_if_missing("partidas", "condiciones_particulares", "TEXT")
    add_col_if_missing("partidas", "aceptada_cliente", "INTEGER DEFAULT 1")
    add_col_if_missing("partidas", "fecha_recepcion_equipo", "TEXT")
    add_col_if_missing("partidas", "fecha_inicio_calibracion", "TEXT")
    add_col_if_missing("partidas", "fecha_fin_calibracion", "TEXT")
    add_col_if_missing("partidas", "fecha_entrega_equipo", "TEXT")
    add_col_if_missing("partidas", "fecha_entrega_resultados", "TEXT")
    add_col_if_missing("partidas", "fecha_limite_aceptacion", "TEXT")

    conn.commit()
    conn.close()
    load_seed_data()

def load_seed_data():
    conn = get_connection()
    c = conn.cursor()
    
    # 1. Cargar Areas Tecnicas si vacio o refrescar
    areas_path = os.path.join(DATA_DIR, "areas_tecnicas.csv")
    if os.path.exists(areas_path):
        with open(areas_path, mode="r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                c.execute("""
                INSERT OR REPLACE INTO areas_tecnicas (clave, nombre)
                VALUES (?, ?)
                """, (row['Clave'].strip(), row['Nombre'].strip()))
                
    # 2. Cargar Catalogo de Servicios si vacio
    c.execute("SELECT COUNT(*) FROM catalogo_servicios")
    count = c.fetchone()[0]
    cat_path = os.path.join(DATA_DIR, "catalogo_servicios.csv")
    if count == 0 and os.path.exists(cat_path):
        with open(cat_path, mode="r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                c.execute("""
                INSERT INTO catalogo_servicios (
                    clave_servicio, clave_area, nombre_tramite, supuesto,
                    alcance, observaciones, costo, fundamento_juridico,
                    es_in_situ, dias_habiles_defecto
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    row['Clave_Servicio'], row['Clave_Area'], row['Nombre_Tramite'],
                    row['Supuesto'], row['Alcance'], row['Observaciones'],
                    float(row['Costo']), row['Fundamento_Juridico'],
                    row['Es_In_Situ'], int(row['Dias_Habiles_Defecto'])
                ))
                
    conn.commit()
    conn.close()

# Consecutivos Institucionales Oficiales con Sufijo PR
def get_next_solicitud_number():
    """Genera consecutivo exacto: año (4 dígitos) + 3 dígitos + PR (ej. 2026001PR, 2026010PR)."""
    conn = get_connection()
    c = conn.cursor()
    year = datetime.now().year
    c.execute("SELECT no_solicitud FROM solicitudes_master ORDER BY id DESC")
    rows = c.fetchall()
    conn.close()
    
    max_num = 0
    for r in rows:
        val = str(r['no_solicitud'] or '')
        # Detectar patrones como 2026009PR o 260651
        m = re.search(r"(\d+)(?:PR)?$", val, re.IGNORECASE)
        if m:
            try:
                digits = m.group(1)
                # Extraer los últimos 3 o 4 dígitos
                seq = int(digits[-3:])
                if seq > max_num:
                    max_num = seq
            except ValueError:
                pass
                
    next_seq = max_num + 1
    return f"{year}{next_seq:03d}PR"

def get_next_folio_number():
    """Genera consecutivo exacto: 4 dígitos + año + sufijo PR (ej. 0001-2026PR, 0010-2026PR)."""
    conn = get_connection()
    c = conn.cursor()
    year = datetime.now().year
    c.execute("SELECT no_folio FROM solicitudes_master ORDER BY id DESC")
    rows = c.fetchall()
    conn.close()
    
    max_num = 0
    for r in rows:
        val = str(r['no_folio'] or '')
        # Formato 0009-2026PR o 231-2026
        m = re.search(r"^(\d+)-", val)
        if m:
            try:
                seq = int(m.group(1))
                if seq > max_num:
                    max_num = seq
            except ValueError:
                pass
                
    next_seq = max_num + 1
    return f"{next_seq:04d}-{year}PR"

def get_next_cotizacion_number():
    """Genera consecutivo exacto: año (2 dígitos) + 4 dígitos + sufijo PR (ej. 260001PR, 260545PR)."""
    conn = get_connection()
    c = conn.cursor()
    year_prefix = datetime.now().year % 100
    c.execute("SELECT no_cotizacion FROM solicitudes_master WHERE no_cotizacion IS NOT NULL ORDER BY id DESC")
    rows = c.fetchall()
    conn.close()
    
    max_num = 0
    for r in rows:
        val = str(r['no_cotizacion'] or '')
        m = re.search(r"(\d+)(?:PR)?$", val, re.IGNORECASE)
        if m:
            try:
                digits = m.group(1)
                seq = int(digits[-4:])
                if seq > max_num:
                    max_num = seq
            except ValueError:
                pass
                
    next_seq = max_num + 1
    return f"{year_prefix:02d}{next_seq:04d}PR"

# Funciones de Cálculo de Días Hábiles
def restar_dias_habiles(fecha_dt, n_dias=2):
    """Calcula n días hábiles antes de una fecha dada (excluyendo sábados y domingos)."""
    curr = fecha_dt
    dias_restados = 0
    while dias_restados < n_dias:
        curr -= timedelta(days=1)
        if curr.weekday() < 5: # Lunes a Viernes
            dias_restados += 1
    return curr

def sumar_dias_habiles(fecha_dt, n_dias):
    """Calcula n días hábiles después de una fecha dada (excluyendo sábados y domingos)."""
    curr = fecha_dt
    dias_sumados = 0
    while dias_sumados < n_dias:
        curr += timedelta(days=1)
        if curr.weekday() < 5:
            dias_sumados += 1
    return curr

def get_areas_tecnicas():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT clave, nombre FROM areas_tecnicas ORDER BY clave")
    rows = c.fetchall()
    conn.close()
    return [{"clave": r["clave"], "nombre": r["nombre"]} for r in rows]

def get_servicios_por_area(clave_area):
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
        SELECT clave_servicio, supuesto, alcance, observaciones, costo, dias_habiles_defecto, es_in_situ
        FROM catalogo_servicios
        WHERE clave_area = ?
        ORDER BY supuesto
    """, (clave_area,))
    rows = c.fetchall()
    conn.close()
    return [dict(r) for r in rows]

if __name__ == "__main__":
    init_db()
    print("Base de datos local inicializada y actualizada con éxito.")
    print("Siguiente Solicitud:", get_next_solicitud_number())
    print("Siguiente Folio:", get_next_folio_number())
    print("Siguiente Cotización:", get_next_cotizacion_number())
